package juego;


import java.awt.Color;
import java.io.File;
import java.io.IOException;

import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;

import entorno.Entorno;
import entorno.InterfaceJuego;

public class DemoMidi extends InterfaceJuego
{
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;
	Sequence secuencia;
	String miFont= "Arial";
	float velocidad;
	Sequencer secuenciador;
	
	// Variables y métodos propios de cada grupo
	// ...
	
	DemoMidi()
	{
		// Inicializa el objeto entorno
		this.entorno = new Entorno(this, "Demo Midi", 800, 600);
		miFont= "Arial";
		velocidad=1;
		
		try {
			secuencia = MidiSystem.getSequence(ClassLoader.getSystemResource("Super_Mario_World_SNES.mid"));
			secuenciador = MidiSystem.getSequencer();
		    secuenciador.open();
		    secuenciador.setSequence(secuencia);
		    secuenciador.setTempoFactor( velocidad);
		    secuenciador.setLoopCount(10);
		    secuenciador.start();
		    	    
			
		} catch (InvalidMidiDataException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MidiUnavailableException e) {
			e.printStackTrace();
		}
		
		
		
		
		// Inicializar lo que haga falta para el juego
		// ...
		
		
		
System.out.println(secuencia.getTracks()[2].size());
		this.entorno.iniciar();
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y 
	 * por lo tanto es el método más importante de esta clase. Aquí se debe 
	 * actualizar el estado interno del juego para simular el paso del tiempo 
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick()
	{
		// Procesamiento de un instante de tiempo
		// ...
		
	
		
		
		Color miColor = new Color (153, 255, 204);
		
		entorno.cambiarFont("Arial", 200, miColor, entorno.NEGRITA);
		
		if(entorno.estaPresionada(entorno.TECLA_ARRIBA)) {
			velocidad=  velocidad*1.01F;
			 secuenciador.setTempoFactor( velocidad);
			
		}
		if(entorno.estaPresionada(entorno.TECLA_ABAJO)) {
			velocidad=  velocidad/1.01F;
			 secuenciador.setTempoFactor( velocidad);
			
		}
		
		
		if(entorno.sePresiono(entorno.TECLA_ESPACIO) && secuenciador.isRunning()  ) {
			
			secuenciador.stop();
		}
		
       if(entorno.sePresiono(entorno.TECLA_DELETE) && !secuenciador.isRunning()  ) {
			
			secuenciador.start();
		}
		
		
		
		entorno.cambiarFont("OCR A Extended", 30, miColor, entorno.NEGRITA);
		entorno.escribirTexto("Velocidad   " + velocidad, 200, 100);
		entorno.escribirTexto(""+secuenciador.isRunning()+"  "+  secuenciador.getMicrosecondLength() , 200, 150);
		
		
		
		
	}
	

	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		DemoMidi juego = new DemoMidi();
	}
}
