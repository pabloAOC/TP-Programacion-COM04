package juego;


import java.awt.Color;

import entorno.Entorno;
import entorno.InterfaceJuego;

public class DemoRelojito extends InterfaceJuego
{
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;
	int horas;
	int minutos;
	int segundos;
	String miFont= "Arial";
	// Variables y métodos propios de cada grupo
	// ...
	
	DemoRelojito()
	{
		// Inicializa el objeto entorno
		this.entorno = new Entorno(this, "Demo Reloj", 800, 600);
		
		// Inicializar lo que haga falta para el juego
		// ...

		
		// Inicia el juego!
		this.entorno.iniciar();
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y 
	 * por lo tanto es el método más importante de esta clase. Aquí se debe 
	 * actualizar el estado interno del juego para simular el paso del tiempo 
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick()
	{
		// Procesamiento de un instante de tiempo
		// ...
		
	
		int sec= entorno.tiempo()/1000;
		segundos= sec%60;
		int min = sec/60;
		minutos= min%60;
		int hor= min/60;
		horas = hor%60;
		
		Color miColor = new Color (153, 255, 204);
		
		entorno.cambiarFont("Arial", 200, miColor, entorno.NEGRITA);
		entorno.escribirTexto(horas +":"+minutos+":"+ segundos  , 100, 350);
		
		
		entorno.cambiarFont(miFont, 30, miColor, entorno.NEGRITA);
		entorno.escribirTexto("Este texto cambia de font" , 200, 100);
		entorno.escribirTexto(miFont , 200, 150);
		
		
		
		if(entorno.tiempo()%100==0) {
			miFont= entorno.fontDisponibles[(int)(1.0*Math.random()*entorno.fontDisponibles.length)];
		}
	}
	

	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		DemoRelojito juego = new DemoRelojito();
	}
}
