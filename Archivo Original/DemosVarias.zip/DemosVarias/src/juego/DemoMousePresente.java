package juego;


import java.awt.Color;

import entorno.Entorno;
import entorno.InterfaceJuego;

public class DemoMousePresente extends InterfaceJuego
{
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;
	
	// Variables y métodos propios de cada grupo
	// ...
	
	DemoMousePresente()
	{
		// Inicializa el objeto entorno
		this.entorno = new Entorno(this, "Demo Mouse Presente", 800, 600);
		
		// Inicializar lo que haga falta para el juego
		// ...
       
		// Inicia el juego!
		this.entorno.iniciar();
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y 
	 * por lo tanto es el método más importante de esta clase. Aquí se debe 
	 * actualizar el estado interno del juego para simular el paso del tiempo 
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick()
	{
		// Procesamiento de un instante de tiempo
		// ...
		if(entorno.mousePresente()) {
			entorno.colorFondo(Color.red);
		}else {
			entorno.colorFondo(Color.black);
		}
	
		
		
		Color miColor = new Color (153, 255, 204);
		entorno.cambiarFont("Tahoma", 42, miColor, entorno.NEGRITA);
		entorno.escribirTexto("Deslizar el mouse dentro ", 100, 200);
		entorno.escribirTexto(" y fuera de la Pantalla", 100, 300);
		
		
	}
	

	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		DemoMousePresente juego = new DemoMousePresente();
	}
}
