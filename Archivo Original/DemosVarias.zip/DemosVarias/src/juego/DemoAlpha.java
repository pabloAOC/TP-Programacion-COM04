package juego;


import java.awt.Color;

import entorno.Entorno;
import entorno.InterfaceJuego;

public class DemoAlpha extends InterfaceJuego
{
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;
	
	// Variables y métodos propios de cada grupo
	// ...
	int alpha;
	
	
	DemoAlpha()
	{
		// Inicializa el objeto entorno
		this.entorno = new Entorno(this, "Demo Alpha", 800, 600);
		this.alpha=255;
		// Inicializar lo que haga falta para el juego
		// ...

		// Inicia el juego!
		this.entorno.iniciar();
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y 
	 * por lo tanto es el método más importante de esta clase. Aquí se debe 
	 * actualizar el estado interno del juego para simular el paso del tiempo 
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick()
	{
		// Procesamiento de un instante de tiempo
		// ...
		

		Color circulo =new Color(10,200,50,alpha);
		Color rectangulo =new Color(200,20,50,255);
		entorno.dibujarRectangulo(400, 400, 300, 300, 0, rectangulo);
		entorno.dibujarCirculo(400, 300, 300, circulo);
		
		
		
		Color miColor = new Color (153, 255, 204);
		entorno.cambiarFont("Tahoma", 42, miColor, entorno.NEGRITA);
		entorno.escribirTexto("apretar flechas arriba y abajo ", 100, 100);
		entorno.escribirTexto(alpha+"", 100, 200);
		

		if (entorno.estaPresionada(entorno.TECLA_ARRIBA)) {
			alpha++;

			if (alpha>255) {
				alpha=255;
			}
		}


		if (entorno.estaPresionada(entorno.TECLA_ABAJO)) {
			alpha--;

			if (alpha<0) {
				alpha=0;
			}
		}

	}


	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		DemoAlpha juego = new DemoAlpha();
	}
}
