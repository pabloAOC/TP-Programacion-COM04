package juego;


import java.awt.Color;

import entorno.Entorno;
import entorno.InterfaceJuego;

public class DemoColores extends InterfaceJuego
{
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;
	int red;
	int green;
	int blue;
	boolean rElegido;
	boolean gElegido;
	boolean bElegido;
	
	// Variables y métodos propios de cada grupo
	// ...
	
	
	
	DemoColores()
	{
		// Inicializa el objeto entorno
		this.entorno = new Entorno(this, "Demo Color", 800, 600);
		
		// Inicializar lo que haga falta para el juego
		
		this.red=125;
		this.green=125;
		this.blue=125;
		this.rElegido=true;
		this.gElegido=false;
		this.bElegido=false;
		
		
		// Inicia el juego!
		this.entorno.iniciar();
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y 
	 * por lo tanto es el método más importante de esta clase. Aquí se debe 
	 * actualizar el estado interno del juego para simular el paso del tiempo 
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick()
	{
		// Procesamiento de un instante de tiempo
		// ...
		
		
		if(rElegido) {
			for (int i=0; i< 256; i++) {
				for (int j=0; j< 256 ; j++) {
					Color puntoColor= new Color(red,i,j);
					entorno.dibujarCirculo(100+i, 264+ j, 1.9, puntoColor);

				}

			}
		}
		
		if(gElegido) {
			for (int i=0; i< 256; i++) {
				for (int j=0; j< 256 ; j++) {
					Color puntoColor= new Color(i,green,j);
					entorno.dibujarCirculo(100+i, 264+j, 1.9, puntoColor);

				}

			}
		}
		
		
		if(bElegido) {
			for (int i=0; i< 256; i++) {
				for (int j=0; j< 256 ; j++) {
					Color puntoColor= new Color(i,j,blue);
					entorno.dibujarCirculo(100+i, 264+j, 1.9, puntoColor);

				}

			}
		}
	
	
	for (int i=0; i< 256; i++) {
			
				Color puntoColor1= new Color(i,0,0);
				Color puntoColor2= new Color(0,i,0);
				Color puntoColor3= new Color(0,0,i);
				entorno.dibujarRectangulo(450, 520-i, 30, 1, 0, puntoColor1);
				entorno.dibujarRectangulo(500,  520-i, 30, 1, 0, puntoColor2);
				entorno.dibujarRectangulo(550,  520-i, 30, 1, 0, puntoColor3);
		
	}
		
	entorno.dibujarRectangulo(222, 225, 256, 30, 0, new Color (red,green,blue));


	if( entorno.sePresionoBoton(entorno.BOTON_IZQUIERDO)) {

		if (entorno.mouseY()>264 && entorno.mouseY()<522) {

			if(entorno.mouseX()>435&& entorno.mouseX()<485 ) {
				
				red= 520-entorno.mouseY();
				rElegido=true;
				bElegido=false;
				gElegido=false;
				
			}
			if(entorno.mouseX()>485 && entorno.mouseX()<535 ) {
				
				green= 520-entorno.mouseY();
				rElegido=false;
				bElegido=false;
				gElegido=true;
			}
			if(entorno.mouseX()>535 && entorno.mouseX()<585 ) {
				
				blue= 520-entorno.mouseY();
				rElegido=false;
				bElegido=true;
				gElegido=false;
			}
		}
	}
		
	if(entorno.sePresionoBoton(entorno.BOTON_IZQUIERDO)   && entorno.mouseX()>95 && entorno.mouseX()<356 
		&&	entorno.mouseY()>264 && entorno.mouseY()<522) {
		
				
		if (rElegido) {
			green= entorno.mouseX()-100;
			blue= entorno.mouseY()-264;
		}
		if (gElegido) {
			red= entorno.mouseX()-100;
			blue= entorno.mouseY()-264;
		}
		
		if (bElegido) {
			red= entorno.mouseX()-100;
			green= entorno.mouseY()-264;
		}
	}
	
		
	
		
		Color textoColor = new Color (213, 231, 247);
		entorno.cambiarFont("Tahoma", 42, textoColor, entorno.NEGRITA);
		entorno.escribirTexto("Elegir el color base", 100, 30);
		entorno.escribirTexto(" Luego elegir un punto del cuadrado ", 6, 60);
		entorno.escribirTexto(" Colores base ", 360, 240);
		entorno.cambiarFont("Tahoma", 28, new Color (255, 0, 0), entorno.NEGRITA);
		entorno.escribirTexto("R= " + red, 40, 200);
		entorno.cambiarFont("Tahoma", 28, new Color (0, 255, 0), entorno.NEGRITA);
		entorno.escribirTexto("G= " + green, 160, 200);
		entorno.cambiarFont("Tahoma", 28, new Color (0, 0, 255), entorno.NEGRITA);
		entorno.escribirTexto("B= " + blue, 270, 200);
		
	}
	

	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		DemoColores juego = new DemoColores();
	}
}
