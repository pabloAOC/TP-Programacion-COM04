package juego;

import java.awt.Color;
import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;

public class Canion {

	// Variables de instancia
		double x;
		double y;
		double c_x;
		double c_y;
		double angulo;
		double escala;
		Image imagen;
		
		
		
		
		public Canion(double x, double y, String archivo) {
			
			this.x = x;
			this.y = y;
		
			
			this.angulo=0;
			this.escala=1;
			
			
			imagen = Herramientas.cargarImagen(archivo);
			this.c_x=imagen.getWidth(null)-10;
			this.c_y=imagen.getHeight(null)-10;
			
			
		}
		
		public void dibujarse(Entorno entorno)
		{
			entorno.dibujarImagenConCentro(imagen, x, y, c_x, c_y, angulo, escala);
		}


		public void girar(double modificador) 
		{
			this.angulo = this.angulo + modificador;
		}
		
		public void apuntar(double x, double y) 
		{
			this.angulo = Math.atan2(600-this.y, 400-this.x);
		}
				
	
		public double getAncho() {
			return imagen.getWidth(null)*this.escala;
		}
		public double getAlto() {
			return imagen.getHeight(null)*this.escala;
		}
		public double getTecho() {
			return this.y-this.getAlto()/2;

		}
		public double getPiso() {
			return this.y+this.getAlto()/2;
		}

		public double getIzquierda() {
			return this.x-this.getAncho()/2;

		}
		public double getDerecha() {
			return this.x+this.getAncho()/2;
		}

		public double getX() {
			return x;
		}

		public double getY() {
			return y;
		}

		
		
		
}
