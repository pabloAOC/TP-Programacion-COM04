package juego;


import java.awt.Color;

import entorno.Entorno;
import entorno.InterfaceJuego;

public class DemoMouse extends InterfaceJuego
{
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;
	
	// Variables y métodos propios de cada grupo
	// ...
	double angulo;
	Color flechaColor;
	
	DemoMouse()
	{
		// Inicializa el objeto entorno
		this.entorno = new Entorno(this, "Demo Mouse", 800, 600);
		
		// Inicializar lo que haga falta para el juego
		// ...
		this.angulo=0;
		this.flechaColor =  new Color( (int)(Math.random()*250.0), (int)(Math.random()*250.0), (int)(Math.random()*250.0));;
		
		// Inicia el juego!
		this.entorno.iniciar();
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y 
	 * por lo tanto es el método más importante de esta clase. Aquí se debe 
	 * actualizar el estado interno del juego para simular el paso del tiempo 
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick()
	{
		// Procesamiento de un instante de tiempo
		// ...
		
		
		if(entorno.estaPresionado(entorno.BOTON_IZQUIERDO )) {
			//	System.out.println("se apreto boton3");
				angulo= Math.atan2(entorno.mouseY()-  500, entorno.mouseX()-400);
				
				}
			
		
		if (Math.abs(angulo-Math.PI/2)< 0.1) {
			
			flechaColor = new Color( (int)(Math.random()*250.0), (int)(Math.random()*250.0), (int)(Math.random()*250.0));

		}
		
		
	
		
		entorno.dibujarTriangulo(400, 400, 400, 50, angulo, flechaColor);
	
		
		Color textoColor = new Color (213, 231, 247);
		entorno.cambiarFont("Tahoma", 42, textoColor, entorno.NEGRITA);
		entorno.escribirTexto("Mover el puntero del mouse", 100, 50);
		entorno.escribirTexto(" mientras se presiona boton izquierdo", 5, 100);
		entorno.cambiarFont("Tahoma", 31,flechaColor, entorno.ITALICA);
		entorno.escribirTexto(" Cuando la flecha quede boca abajo cambiara de color", 6, 130);
		
	}
	

	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		DemoMouse juego = new DemoMouse();
	}
}
