package juego;

import java.awt.Color;
import entorno.Entorno;

public class BolaDeFuego {
    private double x;
    private double y;
    private double velocidad;
    private int dano;
    
    public BolaDeFuego(double x, double y) {
        this.x = x;
        this.y = y;
        this.velocidad = 2.0; // Velocidad moderada
        this.dano = 1;
    }
    
    public double getX() { return x; }
    public double getY() { return y; }
    public int getDano() { return dano; }
    
    public void mover() {
        this.x += velocidad; // Se mueve hacia la derecha
    }
    
    public boolean estaFueraDePantalla(int anchoPantalla) {
        return x > anchoPantalla + 50; // +50 para margen
    }
    
    public void dibujar(Entorno entorno) {
        // Bola de fuego principal
        entorno.dibujarCirculo(x, y, 15, Color.ORANGE);
        entorno.dibujarCirculo(x, y, 10, Color.YELLOW);
        
        // Efecto de llamas
        entorno.dibujarRectangulo(x + 8, y, 5, 12, 0.3, Color.RED);
        entorno.dibujarRectangulo(x - 8, y, 5, 12, -0.3, Color.RED);
    }
}