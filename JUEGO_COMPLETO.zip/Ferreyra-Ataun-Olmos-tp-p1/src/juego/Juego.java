package juego;

import java.awt.Color;
import java.awt.Image;
import entorno.Entorno;
import entorno.InterfaceJuego;
import entorno.Herramientas;

/**
 * JUEGO PRINCIPAL: LA INVASIÓN DE LOS ZOMBIES GRINCH
 *
 */
public class Juego extends InterfaceJuego {
    
    // ==================== CONSTANTES Y CONFIGURACIÓN ====================
    
	// Configuración de la ventana
	private static final int ANCHO_VENTANA = 800;
	private static final int ALTO_VENTANA = 600;

	// Configuración del césped - OCUPANDO TODA LA PANTALLA
	private static final int FILAS_CESPED = 5;
	private static final int COLUMNAS_CESPED = 9; // Reducido para mejor proporción

	// CÁLCULO DINÁMICO DEL TAMAÑO DE CASILLA
	private int TAMANIO_CASILLA; // Ya no es constante, se calcula

	// POSICIONES CENTRADAS
	private int CESPED_X_INICIO;
	private int CESPED_Y_INICIO;
    
    // Tiempos de recarga de plantas (en ticks)
    private static final int RECARGA_ROSE_BLADE = 150;
    private static final int RECARGA_WALL_NUT = 200;
    private static final int RECARGA_ICE_FLOWER = 180;
    
    // Configuración de niveles
    private static final int TOTAL_NIVELES = 4;
    private static final int ZOMBIES_NIVEL_1 = 50;
    
    // Opciones del menú principal
    private static final String[] OPCIONES_MENU = {
        "JUGAR", 
        "INSTRUCCIONES", 
        "SALIR"
    };
    private static final int[] POSICIONES_Y_MENU = {280, 340, 400};
    
    // ==================== ENUMERACIONES ====================
    
    /**
     * Estados posibles del juego para manejar diferentes pantallas
     */
    private enum EstadoJuego {
        MENU_PRINCIPAL,    // Pantalla principal con opciones
        JUGANDO,           // Juego activo
        INSTRUCCIONES,     // Pantalla de cómo jugar
        GANO,              // Pantalla de victoria
        PERDIO             // Pantalla de game over
    }
    
    // ==================== COMPONENTES PRINCIPALES ====================
    
    // Motor gráfico y estado del juego
    private Entorno entorno;
    private EstadoJuego estadoActual;
    
    // Sistema de menú principal
    private int opcionMenuSeleccionada;
    
    // Imágenes del juego
    private Image imagenFondoMenu;
    private Image avatarRoseBlade;
    private Image avatarWallNut;
    private Image avatarIceFlower;
    
    // ==================== SISTEMA DE NIVELES Y PROGRESO ====================
    
    private int nivelActual;
    private int zombiesParaSiguienteNivel;
    private boolean nivelCompletado;
    private boolean jefeAparecio;
    
    // ==================== CONTROL DE TIEMPO ====================
    
    private long tiempoInicio;
    private long tiempoTranscurrido;
    private boolean tiempoDetenido;
    private boolean juegoPausado;
    
    // ==================== SISTEMA DE PLANTAS ====================
    
    // Matriz que representa el césped con plantas
    private Planta[][] cesped;
    
    // Tiempos de recarga actuales
    private int tiempoCargaRoseBlade;
    private int tiempoCargaWallNut;
    private int tiempoCargaIceFlower;
    
    // ==================== SISTEMA DE SELECCIÓN Y ARRASTRE ====================
    
    private String plantaSeleccionada;          // Tipo de planta seleccionada para colocar
    private boolean arrastrando;                // Si se está arrastrando una planta
    private int plantaArrastradaX, plantaArrastradaY; // Posición del arrastre
    
    // ==================== SISTEMA DE MOVIMIENTO CON TECLADO ====================
    
    private Planta plantaSeleccionadaParaMover; // Planta seleccionada para mover
    private boolean plantaSeleccionadaConTeclado;
    private int filaPlantaSeleccionada;
    private int columnaPlantaSeleccionada;
    
    // ==================== SISTEMA DE OBJETIVOS Y ENEMIGOS ====================
    
    private Regalo[] regalos;                   // Objetivos a proteger
    private Object[] zombies;                   // Array de enemigos (puede contener diferentes tipos)
    private ZombieBoss jefe;                    // Jefe final (nivel 4)
    
    // ==================== SISTEMA DE DISPAROS Y PROYECTILES ====================
    
    private BolaDeFuego[] bolasFuego;
    private BolaDeHielo[] bolasHielo;
    
    // ==================== ESTADÍSTICAS Y PROGRESO ====================
    
    private int zombiesEliminados;
    private int zombiesRestantes;
    private int tickGeneracionZombie;
    
    // =====================================================================
    // CONSTRUCTOR PRINCIPAL
    // =====================================================================
    
    /**
     * Inicializa todos los sistemas del juego y configura el entorno gráfico
     */
    public Juego() {
        // Configurar entorno gráfico
        this.entorno = new Entorno(this, "La Invasión de los Zombies Grinch", ANCHO_VENTANA, ALTO_VENTANA);
        
        // Inicializar sistemas en orden
        calcularDimensionesCesped();
        inicializarSistemaEstados();
        inicializarSistemaNiveles();
        inicializarSistemaTiempo();
        inicializarSistemaCesped();
        inicializarSistemaObjetivos();
        inicializarSistemaEnemigos();
        inicializarSistemaDisparos();
        inicializarSistemaPlantas();
        inicializarSistemaSeleccion();
        cargarImagenesMenu(); // Cargar imágenes del menú
        
        // Iniciar bucle principal del juego
        this.entorno.iniciar();
    }
    
    // =====================================================================
    // MÉTODOS DE INICIALIZACIÓN
    // =====================================================================
    
    /**
     * Configura el estado inicial y sistema de menús
     */
    private void inicializarSistemaEstados() {
        this.estadoActual = EstadoJuego.MENU_PRINCIPAL;
        this.opcionMenuSeleccionada = 0;
        this.juegoPausado = false;
    }
    
    /**
     * Configura el sistema de niveles y progresión
     */
    private void inicializarSistemaNiveles() {
        this.nivelActual = 1;
        this.zombiesParaSiguienteNivel = ZOMBIES_NIVEL_1;
        this.nivelCompletado = false;
        this.jefeAparecio = false;
    }
    
    /**
     * Configura el sistema de control de tiempo
     */
    private void inicializarSistemaTiempo() {
        this.tiempoInicio = System.currentTimeMillis();
        this.tiempoTranscurrido = 0;
        this.tiempoDetenido = false;
    }
    
    /**
     * Calcula las dimensiones del césped para ocupar toda la pantalla
     */
    private void calcularDimensionesCesped() {
        // Margen superior para la barra de información
        int margenSuperior = 120;
        int margenInferior = 50;
        int margenLateral = 20;
        
        // Área disponible para el césped
        int anchoDisponible = ANCHO_VENTANA - (2 * margenLateral);
        int altoDisponible = ALTO_VENTANA - margenSuperior - margenInferior;
        
        // Calcular tamaño de casilla basado en la dimensión más restrictiva
        int tamCasillaPorAncho = anchoDisponible / COLUMNAS_CESPED;
        int tamCasillaPorAlto = altoDisponible / FILAS_CESPED;
        
        // Usar el tamaño más pequeño para mantener proporción
        this.TAMANIO_CASILLA = Math.min(tamCasillaPorAncho, tamCasillaPorAlto);
        
        // Calcular posiciones iniciales para centrar
        int anchoTotalCesped = COLUMNAS_CESPED * TAMANIO_CASILLA;
        int altoTotalCesped = FILAS_CESPED * TAMANIO_CASILLA;
        
        this.CESPED_X_INICIO = margenLateral + (anchoDisponible - anchoTotalCesped) / 2 + TAMANIO_CASILLA / 2;
        this.CESPED_Y_INICIO = margenSuperior + (altoDisponible - altoTotalCesped) / 2 + TAMANIO_CASILLA / 2;
    }
    
    /**
     * Inicializa la matriz del césped (tablero de juego)
     */
    private void inicializarSistemaCesped() {
        this.cesped = new Planta[FILAS_CESPED][COLUMNAS_CESPED];
        for (int fila = 0; fila < FILAS_CESPED; fila++) {
            for (int columna = 0; columna < COLUMNAS_CESPED; columna++) {
                cesped[fila][columna] = null;
            }
        }
    }
    
    /**
     * Configura los regalos que deben ser protegidos
     */
    private void inicializarSistemaObjetivos() {
        this.regalos = new Regalo[FILAS_CESPED];
        for (int i = 0; i < FILAS_CESPED; i++) {
            int x = CESPED_X_INICIO; // Columna 0
            int y = CESPED_Y_INICIO + i * TAMANIO_CASILLA;
            regalos[i] = new Regalo(x, y);
        }
    }
    
    /**
     * Inicializa arrays para enemigos y sistema de generación
     */
    private void inicializarSistemaEnemigos() {
        this.zombies = new Object[25];
        this.zombiesEliminados = 0;
        this.zombiesRestantes = zombiesParaSiguienteNivel;
        this.tickGeneracionZombie = 0;
        this.jefe = null;
    }
    
    /**
     * Configura arrays para proyectiles y disparos
     */
    private void inicializarSistemaDisparos() {
        this.bolasFuego = new BolaDeFuego[100];
        this.bolasHielo = new BolaDeHielo[50];
    }
    
    /**
     * Carga recursos de plantas y configura tiempos de recarga
     */
    private void inicializarSistemaPlantas() {
        // Cargar imágenes de avatares
        cargarImagenesPlantas();
        
        // Inicializar tiempos de recarga
        this.tiempoCargaRoseBlade = 0;
        this.tiempoCargaWallNut = 0;
        this.tiempoCargaIceFlower = 0;
    }
    
    /**
     * Carga imágenes para el menú principal
     */
    private void cargarImagenesMenu() {
        try {
            this.imagenFondoMenu = Herramientas.cargarImagen("img/fondo_menu.png");
            System.out.println("Imagen de fondo del menú cargada correctamente");
        } catch (Exception e) {
            System.out.println("No se pudo cargar fondo_menu.jpg: " + e.getMessage());
            System.out.println("Usando fondo de color por defecto");
            this.imagenFondoMenu = null;
        }
    }
    
    /**
     * Carga las imágenes de las plantas desde archivos (avatares)
     */
    private void cargarImagenesPlantas() {
        try {
            this.avatarRoseBlade = Herramientas.cargarImagen("img/rose_blade.png");
            this.avatarWallNut = Herramientas.cargarImagen("img/nuez.png");
            this.avatarIceFlower = Herramientas.cargarImagen("img/ice_flower.png");
        } catch (Exception e) {
            System.out.println("Error al cargar imágenes de plantas: " + e.getMessage());
            // Usar placeholders geométricos si falla la carga
            this.avatarRoseBlade = null;
            this.avatarWallNut = null;
            this.avatarIceFlower = null;
        }
    }
    
    /**
     * Configura el sistema de selección y arrastre
     */
    private void inicializarSistemaSeleccion() {
        this.plantaSeleccionada = null;
        this.arrastrando = false;
        this.plantaSeleccionadaParaMover = null;
        this.plantaSeleccionadaConTeclado = false;
        this.filaPlantaSeleccionada = -1;
        this.columnaPlantaSeleccionada = -1;
    }
    
    // =====================================================================
    // BUCLE PRINCIPAL DEL JUEGO
    // =====================================================================
    
    /**
     * Método principal llamado en cada frame del juego
     * Delega a diferentes sistemas según el estado actual
     */
    public void tick() {
        switch (estadoActual) {
            case MENU_PRINCIPAL:
                ejecutarMenuPrincipal();
                break;
                
            case INSTRUCCIONES:
                ejecutarPantallaInstrucciones();
                break;
                
            case JUGANDO:
                ejecutarJuegoPrincipal();
                break;
                
            case GANO:
                ejecutarPantallaVictoria();
                break;
                
            case PERDIO:
                ejecutarPantallaGameOver();
                break;
        }
    }
    
    // =====================================================================
    // SISTEMA DE MENÚ PRINCIPAL - CON FONDO DE IMAGEN
    // =====================================================================
    
    /**
     * Ejecuta la lógica completa del menú principal
     */
    private void ejecutarMenuPrincipal() {
        dibujarMenuPrincipal();
        procesarInputMenu();
    }
    
    /**
     * Dibuja todos los elementos del menú principal
     */
    private void dibujarMenuPrincipal() {
        dibujarFondoMenu();
        dibujarTituloJuego();
        dibujarOpcionesMenu();
        dibujarElementosDecorativos();
        dibujarInstruccionesNavegacion();
    }
    
    /**
     * Dibuja el fondo del menú principal con imagen
     */
    private void dibujarFondoMenu() {
        if (imagenFondoMenu != null) {
            // Fondo con imagen
            entorno.dibujarImagen(imagenFondoMenu, 400, 300, 0, 1.0);
            // Capa semitransparente para mejor legibilidad
            entorno.dibujarRectangulo(400, 300, 800, 600, 0, new Color(0, 0, 0, 100));
        } else {
            // Fondo de color sólido 
            entorno.dibujarRectangulo(400, 300, 800, 600, 0, new Color(20, 60, 20));
        }
    }
    
    /**
     * Dibuja el título principal del juego
     */
    private void dibujarTituloJuego() {
        entorno.cambiarFont("Arial", 48, Color.GREEN);
        entorno.escribirTexto("ZOMBIE GRINCH WARS", 150, 120);
        
        // Línea decorativa bajo el título
        entorno.dibujarRectangulo(400, 145, 450, 3, 0, new Color(0, 200, 0, 150));
    }
    
    /**
     * Dibuja las opciones seleccionables del menú
     */
    private void dibujarOpcionesMenu() {
        for (int i = 0; i < OPCIONES_MENU.length; i++) {
            boolean seleccionada = (opcionMenuSeleccionada == i);
            dibujarOpcionMenu(OPCIONES_MENU[i], POSICIONES_Y_MENU[i], seleccionada);
        }
    }
    
    /**
     * Dibuja una opción individual del menú
     */
    private void dibujarOpcionMenu(String texto, int posY, boolean seleccionada) {
        // Configurar estilo según si está seleccionada
        if (seleccionada) {
            entorno.cambiarFont("Arial", 32, Color.YELLOW);
            // Efectos visuales para opción seleccionada
            entorno.dibujarRectangulo(200, posY + 15, 180, 3, 0, Color.YELLOW);
            
        } else {
            entorno.cambiarFont("Arial", 28, Color.WHITE);
        }
        
        entorno.escribirTexto(texto, 100, posY);
    }
    
    /**
     * Dibuja elementos decorativos en el menú
     */
    private void dibujarElementosDecorativos() {
        dibujarZombieDecorativo(100, 200);
        dibujarZombieDecorativo(700, 400);
        dibujarEfectosEstrellas();
    }
    
    /**
     * Dibuja instrucciones de control en la parte inferior
     */
    private void dibujarInstruccionesNavegacion() {
        entorno.cambiarFont("Arial", 16, new Color(200, 200, 200, 180));
        entorno.escribirTexto("Usa las flechas ↑↓ para navegar • ENTER para seleccionar", 200, 520);
    }
    
    /**
     * Procesa toda la entrada del usuario en el menú
     */
    private void procesarInputMenu() {
        procesarNavegacionMenu();
        procesarSeleccionMenu();
        procesarSalidaMenu();
    }
    
    /**
     * Maneja la navegación entre opciones del menú
     */
    private void procesarNavegacionMenu() {
        // Movimiento hacia abajo
        if (entorno.sePresiono(entorno.TECLA_ABAJO) || entorno.sePresiono('s')) {
            opcionMenuSeleccionada = (opcionMenuSeleccionada + 1) % OPCIONES_MENU.length;
        }
        
        // Movimiento hacia arriba
        if (entorno.sePresiono(entorno.TECLA_ARRIBA) || entorno.sePresiono('w')) {
            opcionMenuSeleccionada = (opcionMenuSeleccionada - 1 + OPCIONES_MENU.length) % OPCIONES_MENU.length;
        }
    }
    
    /**
     * Maneja la selección de opciones del menú
     */
    private void procesarSeleccionMenu() {
        if (entorno.sePresiono(entorno.TECLA_ENTER)) {
            switch (opcionMenuSeleccionada) {
                case 0: // JUGAR
                    estadoActual = EstadoJuego.JUGANDO;
                    reiniciarJuegoCompleto();
                    break;
                    
                case 1: // INSTRUCCIONES
                    estadoActual = EstadoJuego.INSTRUCCIONES;
                    break;
                    
                case 2: // SALIR
                    System.exit(0);
                    break;
            }
        }
    }
    
    /**
     * Maneja la salida del juego desde el menú
     */
    private void procesarSalidaMenu() {
        if (entorno.sePresiono(entorno.TECLA_ESCAPE)) {
            System.exit(0);
        }
    }
    
    // =====================================================================
    // SISTEMA DE PANTALLA DE INSTRUCCIONES
    // =====================================================================
    
    /**
     * Ejecuta la pantalla de instrucciones
     */
    private void ejecutarPantallaInstrucciones() {
        dibujarPantallaInstrucciones();
        procesarInputInstrucciones();
    }
    
    /**
     * Dibuja la pantalla de instrucciones
     */
    private void dibujarPantallaInstrucciones() {
        // Fondo
        entorno.dibujarRectangulo(400, 300, 800, 600, 0, new Color(20, 40, 80));
        
        // Título
        entorno.cambiarFont("Arial", 36, Color.CYAN);
        entorno.escribirTexto("INSTRUCCIONES", 200, 80);
        
        // Lista de instrucciones
        entorno.cambiarFont("Arial", 18, Color.WHITE);
        String[] instrucciones = {
            "• Coloca plantas haciendo clic en la barra superior",
            "• Usa WASD o flechas para mover plantas seleccionadas", 
            "• Protege los regalos de los zombies",
            "• RoseBlade: Dispara fuego • IceFlower: Ralentiza",
            "• Super zombies son inmunes a congelación completa",
            "• Derrota al jefe en el nivel 4 para ganar"
        };
        
        for (int i = 0; i < instrucciones.length; i++) {
            entorno.escribirTexto(instrucciones[i], 200, 150 + i * 30);
        }
        
        // Instrucción para volver
        entorno.cambiarFont("Arial", 24, Color.YELLOW);
        entorno.escribirTexto("Presiona ESC para volver al menú", 200, 450);
    }
    
    /**
     * Procesa input en pantalla de instrucciones
     */
    private void procesarInputInstrucciones() {
        if (entorno.sePresiono(entorno.TECLA_ESCAPE)) {
            estadoActual = EstadoJuego.MENU_PRINCIPAL;
        }
    }
    
    // =====================================================================
    // SISTEMA PRINCIPAL DEL JUEGO
    // =====================================================================
    
    /**
     * Ejecuta un frame completo del juego principal
     */
    private void ejecutarJuegoPrincipal() {
        actualizarSistemas();
        dibujarElementosJuego();
        procesarInputJuego();
        verificarCondicionesJuego();
    }
    
    /**
     * Actualiza todos los sistemas del juego
     */
    private void actualizarSistemas() {
        if (!tiempoDetenido) {
            tiempoTranscurrido = System.currentTimeMillis() - tiempoInicio;
        }
        
        actualizarTiemposRecarga();
        actualizarPlantas();
        actualizarEnemigos();
        actualizarProyectiles();
        generarNuevosZombies();
        manejarDisparos();
        manejarColisiones();
        limpiarElementosMuertos();
    }
    
    /**
     * Dibuja todos los elementos visuales del juego
     */
    private void dibujarElementosJuego() {
        dibujarFondo();
        dibujarCesped();
        dibujarRegalos();
        dibujarPlantas();
        dibujarBarraSuperior();
        dibujarEnemigos();
        dibujarProyectiles();
        dibujarElementosSeleccion();
    }
    
    /**
     * Procesa la entrada del usuario durante el juego
     */
    private void procesarInputJuego() {
        manejarSeleccionYArrastre();
        manejarSeleccionConTeclado();
        manejarMovimientoConTeclado();
        
        // Volver al menú principal
        if (entorno.sePresiono(entorno.TECLA_ESCAPE)) {
            estadoActual = EstadoJuego.MENU_PRINCIPAL;
        }
    }
    
    /**
     * Verifica condiciones de victoria/derrota
     */
    private void verificarCondicionesJuego() {
        verificarDerrota();
        verificarAvanceNivel();
        verificarVictoria();
    }
    
    // =====================================================================
    // SISTEMA DE CÉSPED 
    // =====================================================================
    
    /**
     * Calcula la posición X correcta para una columna del césped 
     */
    private int calcularPosicionXCesped(int columna) {
        return CESPED_X_INICIO + columna * TAMANIO_CASILLA;
    }
    
    /**
     * Calcula la posición Y correcta para una fila del césped 
     */
    private int calcularPosicionYCesped(int fila) {
        return CESPED_Y_INICIO + fila * TAMANIO_CASILLA;
    }
    
    /**
     * Dibuja la cuadrícula del césped
     */
    /**
     * Dibuja la cuadrícula del césped ocupando toda la pantalla
     */
    private void dibujarCesped() {
        for (int fila = 0; fila < FILAS_CESPED; fila++) {
            for (int columna = 0; columna < COLUMNAS_CESPED; columna++) {
                int x = CESPED_X_INICIO + columna * TAMANIO_CASILLA;
                int y = CESPED_Y_INICIO + fila * TAMANIO_CASILLA;
                
                // Color de fondo
                Color colorCesped = (columna == 0) ? new Color(255, 200, 200, 150) : new Color(200, 255, 200, 150);
                
                // Fondo semitransparente
                entorno.dibujarRectangulo(x, y, TAMANIO_CASILLA, TAMANIO_CASILLA, 0, colorCesped);
                
                // Bordes con líneas
                int medio = TAMANIO_CASILLA / 2;
                entorno.dibujarRectangulo(x, y - medio, TAMANIO_CASILLA, 1, 0, Color.BLACK);
                entorno.dibujarRectangulo(x, y + medio, TAMANIO_CASILLA, 1, 0, Color.BLACK);
                entorno.dibujarRectangulo(x - medio, y, 1, TAMANIO_CASILLA, 0, Color.BLACK);
                entorno.dibujarRectangulo(x + medio, y, 1, TAMANIO_CASILLA, 0, Color.BLACK);
                
                // Etiquetar filas
                if (columna == 0) {
                    entorno.cambiarFont("Arial", 12, Color.BLACK);
                    entorno.escribirTexto("F" + fila, x - 20, y);
                }
            }
        }
    }
    
    /**
     * Dibuja los regalos (objetivos a proteger) 
     */
    private void dibujarRegalos() {
        for (Regalo regalo : regalos) {
            regalo.dibujar(entorno);
        }
    }
    
    // =====================================================================
    // SISTEMA DE ACTUALIZACIÓN DEL JUEGO
    // =====================================================================
    
    /**
     * Actualiza los tiempos de recarga de las plantas
     */
    private void actualizarTiemposRecarga() {
        if (tiempoCargaRoseBlade > 0) tiempoCargaRoseBlade--;
        if (tiempoCargaWallNut > 0) tiempoCargaWallNut--;
        if (nivelActual >= 2 && tiempoCargaIceFlower > 0) tiempoCargaIceFlower--;
    }
    
    /**
     * Actualiza el estado de todas las plantas
     */
    private void actualizarPlantas() {
        for (int fila = 0; fila < FILAS_CESPED; fila++) {
            for (int columna = 0; columna < COLUMNAS_CESPED; columna++) {
                if (cesped[fila][columna] != null) {
                    if (cesped[fila][columna] instanceof RoseBlade) {
                        ((RoseBlade) cesped[fila][columna]).actualizar();
                    } else if (cesped[fila][columna] instanceof IceFlower) {
                        ((IceFlower) cesped[fila][columna]).actualizar();
                    }
                }
            }
        }
    }
    
    /**
     * Actualiza posición y estado de todos los enemigos 
     */
    private void actualizarEnemigos() {
        for (int i = 0; i < zombies.length; i++) {
            if (zombies[i] != null) {
                if (zombies[i] instanceof ZombieGrinch) {
                    ZombieGrinch zombie = (ZombieGrinch) zombies[i];
                    actualizarZombieNormal(zombie, i);
                } else if (zombies[i] instanceof SuperZombieGrinch) {
                    SuperZombieGrinch superZombie = (SuperZombieGrinch) zombies[i];
                    actualizarSuperZombie(superZombie, i);
                }
            }
        }
        
        actualizarJefe();
    }
    
    /**
     * Actualiza un zombie normal
     */
    private void actualizarZombieNormal(ZombieGrinch zombie, int indice) {
        if (zombie.estaMuerto()) {
            zombies[indice] = null;
            zombiesEliminados++;
            zombiesRestantes--;
        } else {
            zombie.mover(cesped);
            zombie.atacar();
        }
    }
    
    /**
     * Actualiza un super zombie
     */
    private void actualizarSuperZombie(SuperZombieGrinch superZombie, int indice) {
        if (superZombie.estaMuerto()) {
            zombies[indice] = null;
            zombiesEliminados++;
            zombiesRestantes--;
        } else {
            superZombie.mover(cesped);
            superZombie.atacar();
        }
    }
    
    /**
     * Actualiza el jefe final
     */
    private void actualizarJefe() {
        if (jefe != null) {
            if (jefe.estaMuerto()) {
                jefe = null;
                zombiesEliminados += 10;
                zombiesRestantes = Math.max(0, zombiesRestantes - 10);
            } else {
                jefe.actualizar();
                jefe.mover();
                
                // Ataque especial del jefe
                if (jefe.isAtaqueActivo()) {
                    jefe.ejecutarAtaque(cesped);
                }
            }
        }
    }
    
    /**
     * Actualiza posición de todos los proyectiles
     */
    private void actualizarProyectiles() {
        actualizarBolasFuego();
        actualizarBolasHielo();
    }
    
    /**
     * Actualiza las bolas de fuego
     */
    private void actualizarBolasFuego() {
        for (int i = 0; i < bolasFuego.length; i++) {
            if (bolasFuego[i] != null) {
                if (bolasFuego[i].estaFueraDePantalla(ANCHO_VENTANA)) {
                    bolasFuego[i] = null;
                } else {
                    bolasFuego[i].mover();
                }
            }
        }
    }
    
    /**
     * Actualiza las bolas de hielo
     */
    private void actualizarBolasHielo() {
        for (int i = 0; i < bolasHielo.length; i++) {
            if (bolasHielo[i] != null) {
                if (bolasHielo[i].estaFueraDePantalla(ANCHO_VENTANA)) {
                    bolasHielo[i] = null;
                } else {
                    bolasHielo[i].mover();
                }
            }
        }
    }
    
    /**
     * Genera nuevos zombies según la progresión del nivel 
     */
    private void generarNuevosZombies() {
        tickGeneracionZombie++;
        
        int frecuencia = obtenerFrecuenciaGeneracion();
        
        if (tickGeneracionZombie >= frecuencia && zombiesRestantes > 0) {
            for (int i = 0; i < zombies.length; i++) {
                if (zombies[i] == null) {
                    zombies[i] = crearZombieSegunNivel();
                    if (zombies[i] != null) {
                        tickGeneracionZombie = 0;
                    }
                    break;
                }
            }
        }
        
        // Generar jefe en nivel 4
        if (nivelActual == 4 && !jefeAparecio && zombiesEliminados >= 25) {
            generarJefe();
        }
    }
    
    /**
     * Obtiene la frecuencia de generación según el nivel
     */
    private int obtenerFrecuenciaGeneracion() {
        switch (nivelActual) {
            case 1: return 180;
            case 2: return 150;
            case 3: return 120;
            case 4: return 200;
            default: return 180;
        }
    }
    
    /**
     * Crea un zombie según las probabilidades del nivel actual 
     */
    private Object crearZombieSegunNivel() {
        int filaAleatoria = (int)(Math.random() * FILAS_CESPED);
        int y = calcularPosicionYCesped(filaAleatoria); // CÁLCULO DINÁMICO
        
        switch (nivelActual) {
            case 1: 
                return new ZombieGrinch(850, y, filaAleatoria);
            case 2:
                if (Math.random() < 0.7) {
                    return new ZombieGrinch(850, y, filaAleatoria);
                } else {
                    return new SuperZombieGrinch(850, y, filaAleatoria);
                }
            case 3: 
                return new SuperZombieGrinch(850, y, filaAleatoria);
            case 4:
                if (Math.random() < 0.4) {
                    return new ZombieGrinch(850, y, filaAleatoria);
                } else if (Math.random() < 0.8) {
                    return new SuperZombieGrinch(850, y, filaAleatoria);
                }
                return null;
            default: 
                return new ZombieGrinch(850, y, filaAleatoria);
        }
    }
    
    /**
     * Genera el jefe final 
     */
    private void generarJefe() {
        if (jefe == null) {
            int y = calcularPosicionYCesped(2); // USA CÁLCULO DINÁMICO
            jefe = new ZombieBoss(850, y);
            jefeAparecio = true;
        }
    }
    // =====================================================================
    // SISTEMA DE DISPAROS Y COLISIONES
    // =====================================================================
    
    /**
     * Maneja la creación de disparos de todas las plantas
     */
    private void manejarDisparos() {
        for (int fila = 0; fila < FILAS_CESPED; fila++) {
            for (int columna = 0; columna < COLUMNAS_CESPED; columna++) {
                if (cesped[fila][columna] != null && cesped[fila][columna].estaViva()) {
                    manejarDisparosRoseBlade(fila, columna);
                    manejarDisparosIceFlower(fila, columna);
                }
            }
        }
    }
    
    /**
     * Maneja los disparos de RoseBlade (bolas de fuego)
     */
    private void manejarDisparosRoseBlade(int fila, int columna) {
        if (cesped[fila][columna] instanceof RoseBlade) {
            RoseBlade roseBlade = (RoseBlade) cesped[fila][columna];
            
            // VERIFICAR ZOMBIES NORMALES Y JEFE - CORRECCIÓN APPLICADA
            boolean hayZombiesNormales = roseBlade.hayZombiesEnFilaYDelante(zombies, fila, cesped[fila][columna].getX());
            boolean hayJefeDelante = (jefe != null && !jefe.estaMuerto() && jefe.getX() > cesped[fila][columna].getX());
            
            if (roseBlade.puedeDisparar() && (hayZombiesNormales || hayJefeDelante)) {
                crearBolaFuego(cesped[fila][columna].getX() + 30, cesped[fila][columna].getY());
                roseBlade.reiniciarRecarga();
            }
        }
    }
    
    /**
     * Maneja los disparos de IceFlower (bolas de hielo)
     */
    private void manejarDisparosIceFlower(int fila, int columna) {
        if (cesped[fila][columna] instanceof IceFlower) {
            IceFlower iceFlower = (IceFlower) cesped[fila][columna];
            
            // VERIFICAR ZOMBIES NORMALES Y JEFE - CORRECCIÓN APPLICADA
            boolean hayZombiesNormales = iceFlower.hayZombiesEnFilaYDelante(zombies, fila, cesped[fila][columna].getX());
            boolean hayJefeDelante = (jefe != null && !jefe.estaMuerto() && jefe.getX() > cesped[fila][columna].getX());
            
            if (iceFlower.puedeDisparar() && (hayZombiesNormales || hayJefeDelante)) {
                crearBolaHielo(cesped[fila][columna].getX() + 30, cesped[fila][columna].getY());
                iceFlower.reiniciarRecarga();
            }
        }
    }
    
    /**
     * Crea una nueva bola de fuego
     */
    private void crearBolaFuego(double x, double y) {
        for (int i = 0; i < bolasFuego.length; i++) {
            if (bolasFuego[i] == null) {
                bolasFuego[i] = new BolaDeFuego(x, y);
                break;
            }
        }
    }
    
    /**
     * Crea una nueva bola de hielo
     */
    private void crearBolaHielo(double x, double y) {
        for (int i = 0; i < bolasHielo.length; i++) {
            if (bolasHielo[i] == null) {
                bolasHielo[i] = new BolaDeHielo(x, y);
                break;
            }
        }
    }
    
    /**
     * Maneja todas las colisiones entre proyectiles y enemigos
     */
    private void manejarColisiones() {
        manejarColisionesFuego();
        manejarColisionesHielo();
    }
    
    /**
     * Maneja colisiones de bolas de fuego
     */
    private void manejarColisionesFuego() {
        for (int i = 0; i < bolasFuego.length; i++) {
            if (bolasFuego[i] != null) {
                // Colisión con zombies normales
                boolean colisiono = verificarColisionFuegoConZombies(i);
                
                // Colisión con jefe (si no colisionó con zombies)
                if (!colisiono && jefe != null) {
                    verificarColisionFuegoConJefe(i);
                }
            }
        }
    }
    
    /**
     * Verifica colisión de bola de fuego con zombies
     */
    private boolean verificarColisionFuegoConZombies(int indiceBola) {
        for (int j = 0; j < zombies.length; j++) {
            if (zombies[j] != null) {
                double distanciaX = Math.abs(bolasFuego[indiceBola].getX() - obtenerZombieX(zombies[j]));
                double distanciaY = Math.abs(bolasFuego[indiceBola].getY() - obtenerZombieY(zombies[j]));
                
                if (distanciaX < 30 && distanciaY < 40) {
                    aplicarDanoZombie(zombies[j], 1);
                    bolasFuego[indiceBola] = null;
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Verifica colisión de bola de fuego con jefe
     */
    private void verificarColisionFuegoConJefe(int indiceBola) {
        double distanciaX = Math.abs(bolasFuego[indiceBola].getX() - jefe.getX());
        double distanciaY = Math.abs(bolasFuego[indiceBola].getY() - jefe.getY());
        
        if (distanciaX < 50 && distanciaY < 100) {
            jefe.recibirDano(1);
            bolasFuego[indiceBola] = null;
        }
    }
    
    /**
     * Maneja colisiones de bolas de hielo
     */
    private void manejarColisionesHielo() {
        for (int i = 0; i < bolasHielo.length; i++) {
            if (bolasHielo[i] != null && bolasHielo[i].isActiva()) {
                boolean colisiono = verificarColisionHieloConZombies(i);
                
                if (!colisiono && jefe != null) {
                    verificarColisionHieloConJefe(i);
                }
            }
        }
    }
    
    /**
     * Verifica colisión de bola de hielo con zombies
     */
    private boolean verificarColisionHieloConZombies(int indiceBola) {
        for (int j = 0; j < zombies.length; j++) {
            if (zombies[j] != null) {
                double distanciaX = Math.abs(bolasHielo[indiceBola].getX() - obtenerZombieX(zombies[j]));
                double distanciaY = Math.abs(bolasHielo[indiceBola].getY() - obtenerZombieY(zombies[j]));
                
                if (distanciaX < 30 && distanciaY < 40) {
                    aplicarEfectoHielo(zombies[j], bolasHielo[indiceBola]);
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Verifica colisión de bola de hielo con jefe
     */
    private void verificarColisionHieloConJefe(int indiceBola) {
        double distanciaX = Math.abs(bolasHielo[indiceBola].getX() - jefe.getX());
        double distanciaY = Math.abs(bolasHielo[indiceBola].getY() - jefe.getY());
        
        if (distanciaX < 50 && distanciaY < 100) {
            double factorRalentizacion = 1.0 - (bolasHielo[indiceBola].getHits() * 0.2);
            jefe.aplicarRalentizacion(factorRalentizacion);
            jefe.recibirDano(1);
            bolasHielo[indiceBola].desactivar();
        }
    }
    
    /**
     * Aplica efecto de hielo a un zombie según su tipo
     */
    private void aplicarEfectoHielo(Object zombie, BolaDeHielo bolaHielo) {
        if (zombie instanceof SuperZombieGrinch) {
            aplicarEfectoHieloSuperZombie((SuperZombieGrinch) zombie, bolaHielo);
        } else if (zombie instanceof ZombieGrinch) {
            aplicarEfectoHieloZombieNormal((ZombieGrinch) zombie, bolaHielo);
        }
    }
    
    /**
     * Aplica efecto de hielo a SuperZombie (solo ralentización)
     */
    private void aplicarEfectoHieloSuperZombie(SuperZombieGrinch superZombie, BolaDeHielo bolaHielo) {
        double factorRalentizacion = 1.0 - (bolaHielo.getHits() * 0.15);
        superZombie.aplicarRalentizacion(factorRalentizacion);
        aplicarDanoZombie(superZombie, 1);
        bolaHielo.desactivar();
    }
    
    /**
     * Aplica efecto de hielo a Zombie normal (ralentización + posible congelación)
     */
    private void aplicarEfectoHieloZombieNormal(ZombieGrinch zombie, BolaDeHielo bolaHielo) {
        aplicarEfectoRalentizacion(zombie, bolaHielo.getHits());
        aplicarDanoZombie(zombie, 1);
        bolaHielo.incrementarHits();
        
        // Congelar completamente después de 3 hits
        if (bolaHielo.getHits() >= 3) {
            aplicarCongelacionCompleta(zombie);
            bolaHielo.desactivar();
        }
    }
    
    /**
     * Aplica efecto de ralentización a zombie normal
     */
    private void aplicarEfectoRalentizacion(ZombieGrinch zombie, int hits) {
        double factorRalentizacion = 1.0 - (hits * 0.2);
        factorRalentizacion = Math.max(0.3, factorRalentizacion);
        zombie.setVelocidad(0.5 * factorRalentizacion);
    }
    
    /**
     * Aplica daño a un zombie según su tipo
     */
    private void aplicarDanoZombie(Object zombie, int dano) {
        if (zombie instanceof ZombieGrinch) {
            ZombieGrinch z = (ZombieGrinch) zombie;
            for (int i = 0; i < dano; i++) {
                z.recibirDano();
            }
        } else if (zombie instanceof SuperZombieGrinch) {
            SuperZombieGrinch sz = (SuperZombieGrinch) zombie;
            for (int i = 0; i < dano; i++) {
                sz.recibirDano();
            }
        }
    }
    
    /**
     * Congela completamente un zombie normal
     */
    private void aplicarCongelacionCompleta(ZombieGrinch zombie) {
        zombie.setVelocidad(0);
    }
    
    /**
     * Obtiene la coordenada X de un zombie
     */
    private double obtenerZombieX(Object zombie) {
        if (zombie instanceof ZombieGrinch) {
            return ((ZombieGrinch) zombie).getX();
        } else if (zombie instanceof SuperZombieGrinch) {
            return ((SuperZombieGrinch) zombie).getX();
        }
        return -1000;
    }
    
    /**
     * Obtiene la coordenada Y de un zombie
     */
    private double obtenerZombieY(Object zombie) {
        if (zombie instanceof ZombieGrinch) {
            return ((ZombieGrinch) zombie).getY();
        } else if (zombie instanceof SuperZombieGrinch) {
            return ((SuperZombieGrinch) zombie).getY();
        }
        return -1000;
    }
    
    /**
     * Limpia elementos muertos o fuera de pantalla
     */
    private void limpiarElementosMuertos() {
        limpiarPlantasMuertas();
    }
    
    /**
     * Elimina plantas con salud agotada
     */
    private void limpiarPlantasMuertas() {
        for (int fila = 0; fila < FILAS_CESPED; fila++) {
            for (int columna = 0; columna < COLUMNAS_CESPED; columna++) {
                if (cesped[fila][columna] != null && cesped[fila][columna].getSalud() <= 0) {
                    // Si la planta seleccionada para mover murió, resetear selección
                    if (plantaSeleccionadaParaMover == cesped[fila][columna]) {
                        resetearSeleccionTeclado();
                    }
                    cesped[fila][columna] = null;
                }
            }
        }
    }
    
    // =====================================================================
    // SISTEMA DE DIBUJO DEL JUEGO
    // =====================================================================
    
    /**
     * Dibuja el fondo según el nivel actual
     */
    private void dibujarFondo() {
        Color colorFondo = obtenerColorFondoNivel();
        entorno.dibujarRectangulo(400, 300, 800, 600, 0, colorFondo);
    }
    
    /**
     * Obtiene el color de fondo según el nivel
     */
    private Color obtenerColorFondoNivel() {
        switch (nivelActual) {
            case 1: return new Color(240, 255, 240);
            case 2: return new Color(240, 240, 255);
            case 3: return new Color(255, 240, 240);
            case 4: return new Color(255, 255, 200);
            default: return Color.WHITE;
        }
    }
    
    /**
     * Dibuja todas las plantas en el césped 
     */
    private void dibujarPlantas() {
        for (int fila = 0; fila < FILAS_CESPED; fila++) {
            for (int columna = 0; columna < COLUMNAS_CESPED; columna++) {
                if (cesped[fila][columna] != null) {
                    // FORZAR a la planta a dibujarse en la posición correcta del césped
                    int xCorrecto = CESPED_X_INICIO + columna * TAMANIO_CASILLA;
                    int yCorrecto = CESPED_Y_INICIO + fila * TAMANIO_CASILLA;
                    
                    // Actualizar la posición de la planta antes de dibujar
                    cesped[fila][columna].setX(xCorrecto);
                    cesped[fila][columna].setY(yCorrecto);
                    
                    cesped[fila][columna].dibujar(entorno);
                }
            }
        }
    }
    
    /**
     * Dibuja todos los enemigos en pantalla
     */
    private void dibujarEnemigos() {
        for (Object zombie : zombies) {
            if (zombie != null) {
                if (zombie instanceof ZombieGrinch) {
                    ((ZombieGrinch) zombie).dibujar(entorno);
                } else if (zombie instanceof SuperZombieGrinch) {
                    ((SuperZombieGrinch) zombie).dibujar(entorno);
                }
            }
        }
        
        if (jefe != null) {
            jefe.dibujar(entorno);
        }
    }
    
    /**
     * Dibuja todos los proyectiles en pantalla
     */
    private void dibujarProyectiles() {
        for (BolaDeFuego bolaFuego : bolasFuego) {
            if (bolaFuego != null) {
                bolaFuego.dibujar(entorno);
            }
        }
        
        for (BolaDeHielo bolaHielo : bolasHielo) {
            if (bolaHielo != null) {
                bolaHielo.dibujar(entorno);
            }
        }
    }
    
    /**
     * Dibuja elementos relacionados con selección y arrastre
     */
    private void dibujarElementosSeleccion() {
        dibujarPlantaArrastrada();
        dibujarPlantaSeleccionadaParaMover();
    }
    
    // =====================================================================
    // SISTEMA DE BARRA SUPERIOR (UI)
    // =====================================================================
    
    /**
     * Dibuja la barra superior con información del juego
     */
    private void dibujarBarraSuperior() {
        dibujarFondoBarraSuperior();
        dibujarSeccionNivel(100, 50);
        dibujarSeccionProgreso(250, 50);
        dibujarSeccionPlantas(450, 50);
        dibujarSeccionTiempo(650, 50);
        dibujarSeparadoresBarra();
    }
    
    /**
     * Dibuja el fondo de la barra superior
     */
    private void dibujarFondoBarraSuperior() {
        entorno.dibujarRectangulo(400, 50, 800, 100, 0, new Color(40, 40, 60, 220));
        entorno.dibujarRectangulo(400, 0, 800, 5, 0, new Color(100, 150, 255));
    }
    
    /**
     * Dibuja la sección de información del nivel
     */
    private void dibujarSeccionNivel(int x, int y) {
        // Icono de nivel
        entorno.dibujarRectangulo(x - 40, y, 30, 30, 0, new Color(70, 130, 180));
        entorno.cambiarFont("Arial", 16, Color.WHITE);
        entorno.escribirTexto("" + nivelActual, x - 40, y + 5);
        
        // Información textual
        entorno.cambiarFont("Arial", 14, Color.WHITE);
        entorno.escribirTexto("NIVEL", x, y - 15);
        
        entorno.cambiarFont("Arial", 16, Color.YELLOW);
        entorno.escribirTexto(obtenerNombreNivel(), x, y);
        
        entorno.cambiarFont("Arial", 12, Color.LIGHT_GRAY);
        entorno.escribirTexto(obtenerDescripcionNivel(), x, y + 15);
    }
    
    /**
     * Dibuja la sección de progreso de zombies
     */
    private void dibujarSeccionProgreso(int x, int y) {
        // Icono de zombie
        entorno.dibujarCirculo(x - 40, y, 12, Color.GREEN);
        entorno.dibujarCirculo(x - 40, y - 3, 8, new Color(150, 250, 150));
        
        // Información textual
        entorno.cambiarFont("Arial", 14, Color.WHITE);
        entorno.escribirTexto("ELIMINADOS", x, y - 15);
        
        // Progreso numérico
        entorno.cambiarFont("Arial", 18, Color.CYAN);
        entorno.escribirTexto(zombiesEliminados + " / " + zombiesParaSiguienteNivel, x, y);
        
        // Barra de progreso visual
        dibujarBarraProgresoZombies(x, y);
    }
    
    /**
     * Dibuja la barra de progreso de zombies eliminados
     */
    private void dibujarBarraProgresoZombies(int x, int y) {
        double porcentaje = (double) zombiesEliminados / zombiesParaSiguienteNivel;
        int anchoBarra = 120;
        int progresoBarra = (int) (anchoBarra * Math.min(porcentaje, 1.0));
        
        // Fondo de la barra
        entorno.dibujarRectangulo(x, y + 15, anchoBarra, 8, 0, new Color(100, 100, 100));
        
        // Barra de progreso
        if (progresoBarra > 0) {
            Color colorProgreso = obtenerColorProgreso(porcentaje);
            entorno.dibujarRectangulo(x - anchoBarra/2 + progresoBarra/2, y + 15, progresoBarra, 8, 0, colorProgreso);
        }
        
        // Porcentaje
        entorno.cambiarFont("Arial", 10, Color.WHITE);
        entorno.escribirTexto((int)(porcentaje * 100) + "%", x, y + 25);
    }
    
    /**
     * Obtiene el color de la barra de progreso según el porcentaje
     */
    private Color obtenerColorProgreso(double porcentaje) {
        if (porcentaje >= 1.0) return Color.GREEN;
        if (porcentaje >= 0.7) return Color.YELLOW;
        return Color.ORANGE;
    }
    
    /**
     * Dibuja la sección de plantas disponibles
     */
    private void dibujarSeccionPlantas(int x, int y) {
        entorno.cambiarFont("Arial", 14, Color.WHITE);
        entorno.escribirTexto("PLANTAS", x, y - 15);
        
        // Dibujar avatares de las plantas
        dibujarAvatarRoseBlade(x - 40, y);
        dibujarAvatarWallNut(x, y);
        dibujarAvatarIceFlower(x + 40, y);
    }
    
    /**
     * Dibuja el avatar de RoseBlade
     */
    private void dibujarAvatarRoseBlade(int x, int y) {
        boolean disponible = (tiempoCargaRoseBlade == 0);
        dibujarAvatarPlanta(x, y, avatarRoseBlade, tiempoCargaRoseBlade, 
                           RECARGA_ROSE_BLADE, "Rose Blade", Color.RED, disponible);
    }
    
    /**
     * Dibuja el avatar de WallNut
     */
    private void dibujarAvatarWallNut(int x, int y) {
        boolean disponible = (tiempoCargaWallNut == 0);
        dibujarAvatarPlanta(x, y, avatarWallNut, tiempoCargaWallNut, 
                           RECARGA_WALL_NUT, "Wall Nut", new Color(160, 120, 60), disponible);
    }
    
    /**
     * Dibuja el avatar de IceFlower
     */
    private void dibujarAvatarIceFlower(int x, int y) {
        if (nivelActual >= 2) {
            boolean disponible = (tiempoCargaIceFlower == 0);
            dibujarAvatarPlanta(x, y, avatarIceFlower, tiempoCargaIceFlower, 
                               RECARGA_ICE_FLOWER, "Ice Flower", Color.CYAN, disponible);
        } else {
            dibujarAvatarPlantaBloqueada(x, y, "Ice Flower");
        }
    }
    
    /**
     * Dibuja un avatar de planta genérico
     */
    private void dibujarAvatarPlanta(int x, int y, Image imagen, int tiempoCarga, 
                                   int cargaMaxima, String nombre, Color colorBase, boolean disponible) {
        int tamañoAvatar = 35;
        
        // Fondo del avatar
        Color colorFondo = disponible ? new Color(255, 255, 255, 50) : new Color(0, 0, 0, 100);
        entorno.dibujarRectangulo(x, y, tamañoAvatar, tamañoAvatar, 0, colorFondo);
        
        // Borde según estado
        Color colorBorde = disponible ? Color.GREEN : Color.YELLOW;
        int grosorBorde = disponible ? 2 : 1;
        entorno.dibujarRectangulo(x, y, tamañoAvatar, tamañoAvatar, grosorBorde, colorBorde);
        
        // Imagen o placeholder
        if (imagen != null) {
            double escala = 0.22;
            entorno.dibujarImagen(imagen, x, y, 0, escala);
            
            // Oscurecer si está en recarga
            if (!disponible) {
                entorno.dibujarRectangulo(x, y, tamañoAvatar, tamañoAvatar, 0, new Color(0, 0, 0, 120));
            }
        } else {
            // Placeholder geométrico
            Color colorPlaceholder = disponible ? colorBase : Color.GRAY;
            entorno.dibujarRectangulo(x, y, tamañoAvatar-10, tamañoAvatar-10, 0, colorPlaceholder);
            
            entorno.cambiarFont("Arial", 10, Color.WHITE);
            String abreviatura = nombre.substring(0, 2);
            entorno.escribirTexto(abreviatura, x, y + 5);
        }
        
        // Indicador de estado (listo o en recarga)
        if (disponible) {
            entorno.cambiarFont("Arial", 14, Color.GREEN);
            entorno.escribirTexto("✓", x, y + 5);
        } else {
            dibujarBarraRecarga(x, y, tiempoCarga, cargaMaxima);
        }
        
        // Tooltip al pasar el mouse
        if (estaMouseSobreAvatar(x, y, tamañoAvatar) && disponible) {
            dibujarTooltipPlanta(x, y, nombre);
        }
    }
    
    /**
     * Dibuja la barra de recarga de una planta
     */
    private void dibujarBarraRecarga(int x, int y, int tiempoCarga, int cargaMaxima) {
        double progreso = 1.0 - (double)tiempoCarga / cargaMaxima;
        int anchoBarra = 25;
        
        // Barra de progreso
        entorno.dibujarRectangulo(x, y + 12, anchoBarra * progreso, 4, 0, Color.YELLOW);
        
        // Tiempo restante
        int segundos = (tiempoCarga / 60) + 1;
        entorno.cambiarFont("Arial", 9, Color.YELLOW);
        entorno.escribirTexto(segundos + "s", x, y + 8);
    }
    
    /**
     * Dibuja tooltip informativo para una planta
     */
    private void dibujarTooltipPlanta(int x, int y, String nombre) {
        entorno.dibujarRectangulo(x, y, 35, 35, 2, Color.CYAN);
        
        entorno.cambiarFont("Arial", 10, Color.WHITE);
        entorno.escribirTexto(nombre, x, y - 15);
        entorno.escribirTexto("LISTA", x, y - 25);
    }
    
    /**
     * Dibuja un avatar de planta bloqueada
     */
    private void dibujarAvatarPlantaBloqueada(int x, int y, String nombre) {
        int tamañoAvatar = 35;
        
        // Fondo gris para indicar bloqueado
        entorno.dibujarRectangulo(x, y, tamañoAvatar, tamañoAvatar, 0, Color.DARK_GRAY);
        entorno.dibujarRectangulo(x, y, tamañoAvatar, tamañoAvatar, 2, Color.GRAY);
        
        // Icono de candado
        entorno.cambiarFont("Arial", 16, Color.GRAY);
        entorno.escribirTexto("🔒", x, y + 5);
        
        // Texto del nivel requerido
        entorno.cambiarFont("Arial", 8, Color.LIGHT_GRAY);
        entorno.escribirTexto("Niv " + nivelActual, x, y + 15);
        
        // Tooltip informativo
        if (estaMouseSobreAvatar(x, y, tamañoAvatar)) {
            entorno.cambiarFont("Arial", 10, Color.WHITE);
            entorno.escribirTexto(nombre + " (Nivel " + (nivelActual + 1) + ")", x, y - 20);
        }
    }
    
    /**
     * Dibuja la sección de tiempo y estadísticas
     */
    private void dibujarSeccionTiempo(int x, int y) {
        // Icono de reloj
        dibujarIconoReloj(x - 40, y);
        
        // Tiempo transcurrido
        entorno.cambiarFont("Arial", 14, Color.WHITE);
        entorno.escribirTexto("TIEMPO", x, y - 15);
        
        entorno.cambiarFont("Arial", 18, Color.WHITE);
        entorno.escribirTexto(obtenerTiempoSegundos() + "s", x, y);
        
        // Zombies restantes
        entorno.cambiarFont("Arial", 12, Color.LIGHT_GRAY);
        entorno.escribirTexto("Restantes: " + zombiesRestantes, x, y + 15);
        
        // Indicador de estado del juego
        if (tiempoDetenido) {
            entorno.cambiarFont("Arial", 10, Color.RED);
            entorno.escribirTexto("JUEGO PAUSADO", x, y + 25);
        }
    }
    
    /**
     * Dibuja el icono de reloj
     */
    private void dibujarIconoReloj(int x, int y) {
        entorno.dibujarCirculo(x, y, 12, Color.ORANGE);
        entorno.dibujarCirculo(x, y, 8, Color.YELLOW);
        entorno.dibujarRectangulo(x, y - 8, 2, 6, 0, Color.BLACK);
        entorno.dibujarRectangulo(x, y, 5, 2, 0.5, Color.BLACK);
    }
    
    /**
     * Dibuja separadores entre secciones de la barra
     */
    private void dibujarSeparadoresBarra() {
        int[] separadoresX = {200, 350, 550};
        for (int x : separadoresX) {
            entorno.dibujarRectangulo(x, 10, 2, 80, 0, new Color(255, 255, 255, 80));
        }
        
        // Línea inferior decorativa
        entorno.dibujarRectangulo(400, 100, 800, 2, 0, new Color(100, 150, 255, 150));
    }
    
    // =====================================================================
    // SISTEMA DE SELECCIÓN Y MOVIMIENTO 
    // =====================================================================
    
    /**
     * Maneja la selección y arrastre de plantas con el mouse -
     */
    private void manejarSeleccionYArrastre() {
        int mouseX = entorno.mouseX();
        int mouseY = entorno.mouseY();
        
        if (!plantaSeleccionadaConTeclado && entorno.sePresionoBoton(entorno.BOTON_IZQUIERDO)) {
            manejarClicBarraPlantas(mouseX, mouseY);
            manejarClicCesped(mouseX, mouseY);
        }
        
        manejarArrastrePlanta(mouseX, mouseY);
        manejarSueltaPlanta(mouseX, mouseY);
    }
    
    /**
     * Maneja clics en la barra de plantas para seleccionar
     */
    private void manejarClicBarraPlantas(int mouseX, int mouseY) {
        if (mouseY <= 85 && mouseY >= 35) { // Área de la barra de plantas
            // Rose Blade - posición del avatar
            if (mouseX >= 410 && mouseX <= 445) {
                if (tiempoCargaRoseBlade == 0) {
                    seleccionarPlantaParaColocar("roseblade");
                }
            }
            // Wall Nut
            else if (mouseX >= 450 && mouseX <= 485) {
                if (tiempoCargaWallNut == 0) {
                    seleccionarPlantaParaColocar("wallnut");
                }
            }
            // Ice Flower (solo nivel 2+)
            else if (nivelActual >= 2 && mouseX >= 490 && mouseX <= 525) {
                if (tiempoCargaIceFlower == 0) {
                    seleccionarPlantaParaColocar("iceflower");
                }
            }
        }
    }
    
    /**
     * Maneja clics en el césped para seleccionar plantas existentes 
     */
    private void manejarClicCesped(int mouseX, int mouseY) {
        if (mouseY > 100) {
            for (int fila = 0; fila < FILAS_CESPED; fila++) {
                for (int columna = 0; columna < COLUMNAS_CESPED; columna++) {
                    if (cesped[fila][columna] != null) {
                        Planta planta = cesped[fila][columna];
                        // USA POSICIONES CALCULADAS PARA DETECCIÓN
                        int plantaX = CESPED_X_INICIO + columna * TAMANIO_CASILLA;
                        int plantaY = CESPED_Y_INICIO + fila * TAMANIO_CASILLA;
                        
                        double distanciaX = Math.abs(mouseX - plantaX);
                        double distanciaY = Math.abs(mouseY - plantaY);
                        
                        if (distanciaX < TAMANIO_CASILLA/2 && distanciaY < TAMANIO_CASILLA/2) {
                            seleccionarPlantaParaMover(planta, fila, columna);
                            return;
                        }
                    }
                }
            }
            resetearSeleccionTeclado();
        }
    }
    
    /**
     * Selecciona una planta para colocar (arrastre)
     */
    private void seleccionarPlantaParaColocar(String tipoPlanta) {
        plantaSeleccionada = tipoPlanta;
        arrastrando = true;
        resetearSeleccionTeclado();
    }
    
    /**
     * Selecciona una planta existente para mover
     */
    private void seleccionarPlantaParaMover(Planta planta, int fila, int columna) {
        plantaSeleccionadaParaMover = planta;
        plantaSeleccionadaConTeclado = true;
        filaPlantaSeleccionada = fila;
        columnaPlantaSeleccionada = columna;
        plantaSeleccionada = null;
        arrastrando = false;
    }
    
    /**
     * Maneja el arrastre de una planta seleccionada
     */
    private void manejarArrastrePlanta(int mouseX, int mouseY) {
        if (arrastrando && entorno.estaPresionado(entorno.BOTON_IZQUIERDO)) {
            plantaArrastradaX = mouseX;
            plantaArrastradaY = mouseY;
        }
    }
    
    /**
     * Maneja la suelta de una planta arrastrada 
     */
    private void manejarSueltaPlanta(int mouseX, int mouseY) {
        if (arrastrando && entorno.seLevantoBoton(entorno.BOTON_IZQUIERDO)) {
            arrastrando = false;
            colocarPlantaEnCesped(mouseX, mouseY);
            plantaSeleccionada = null;
        }
    }
    
    /**
     * Intenta colocar una planta en la posición del mouse 
     */
    private void colocarPlantaEnCesped(int mouseX, int mouseY) {
        int[] posicion = obtenerPosicionCesped(mouseX, mouseY);
        int fila = posicion[0];
        int columna = posicion[1];
        
        if (fila != -1 && columna != -1 && columna >= 1 && cesped[fila][columna] == null) {
            crearPlantaEnPosicion(fila, columna);
        }
    }
    
    /**
     * Obtiene la posición en el césped a partir de coordenadas de pantalla 
     */
    private int[] obtenerPosicionCesped(int mouseX, int mouseY) {
        int fila = -1;
        int columna = -1;
        
        // Encontrar fila
        for (int i = 0; i < FILAS_CESPED; i++) {
            int yCasilla = calcularPosicionYCesped(i);
            if (mouseY >= yCasilla - TAMANIO_CASILLA/2 && 
                mouseY <= yCasilla + TAMANIO_CASILLA/2) {
                fila = i;
                break;
            }
        }
        
        // Encontrar columna
        if (fila != -1) {
            for (int j = 0; j < COLUMNAS_CESPED; j++) {
                int xCasilla = calcularPosicionXCesped(j);
                if (mouseX >= xCasilla - TAMANIO_CASILLA/2 && 
                    mouseX <= xCasilla + TAMANIO_CASILLA/2) {
                    columna = j;
                    break;
                }
            }
            
            // Validar que no sea la columna de regalos (columna 0)
            if (columna < 1) {
                fila = -1;
                columna = -1;
            }
        }
        
        return new int[]{fila, columna};
    }
    
    /**
     * Crea una nueva planta en la posición especificada 
     */
    private void crearPlantaEnPosicion(int fila, int columna) {
        int x = CESPED_X_INICIO + columna * TAMANIO_CASILLA;
        int y = CESPED_Y_INICIO + fila * TAMANIO_CASILLA;
        
        if ("roseblade".equals(plantaSeleccionada)) {
            cesped[fila][columna] = new RoseBlade(x, y);
            tiempoCargaRoseBlade = RECARGA_ROSE_BLADE;
        } else if ("wallnut".equals(plantaSeleccionada)) {
            cesped[fila][columna] = new WallNut(x, y);
            tiempoCargaWallNut = RECARGA_WALL_NUT;
        } else if ("iceflower".equals(plantaSeleccionada)) {
            cesped[fila][columna] = new IceFlower(x, y);
            tiempoCargaIceFlower = RECARGA_ICE_FLOWER;
        }
    }
    
    /**
     * Maneja la selección de plantas con teclado
     */
    private void manejarSeleccionConTeclado() {
        if (entorno.sePresiono(entorno.TECLA_ESPACIO)) {
            if (!plantaSeleccionadaConTeclado) {
                seleccionarPrimeraPlantaDisponible();
            }
        }
        
        if (entorno.sePresiono(entorno.TECLA_CTRL)) {
            resetearSeleccionTeclado();
        }
    }
    
    /**
     * Selecciona la primera planta disponible en el césped
     */
    private void seleccionarPrimeraPlantaDisponible() {
        for (int fila = 0; fila < FILAS_CESPED; fila++) {
            for (int columna = 0; columna < COLUMNAS_CESPED; columna++) {
                if (cesped[fila][columna] != null && cesped[fila][columna].estaViva()) {
                    seleccionarPlantaParaMover(cesped[fila][columna], fila, columna);
                    return;
                }
            }
        }
    }
    
    /**
     * Maneja el movimiento de plantas seleccionadas con teclado 
     */
    private void manejarMovimientoConTeclado() {
        if (plantaSeleccionadaConTeclado && plantaSeleccionadaParaMover != null) {
            if (entorno.sePresiono('a') || entorno.sePresiono(entorno.TECLA_IZQUIERDA)) {
                moverPlantaDireccion(-1, 0); // Izquierda
            }
            if (entorno.sePresiono('d') || entorno.sePresiono(entorno.TECLA_DERECHA)) {
                moverPlantaDireccion(1, 0); // Derecha
            }
            if (entorno.sePresiono('w') || entorno.sePresiono(entorno.TECLA_ARRIBA)) {
                moverPlantaDireccion(0, -1); // Arriba
            }
            if (entorno.sePresiono('s') || entorno.sePresiono(entorno.TECLA_ABAJO)) {
                moverPlantaDireccion(0, 1); // Abajo
            }
        }
    }
    
    /**
     * Mueve la planta seleccionada en una dirección específica
     */
    private void moverPlantaDireccion(int deltaColumna, int deltaFila) {
        int nuevaFila = filaPlantaSeleccionada + deltaFila;
        int nuevaColumna = columnaPlantaSeleccionada + deltaColumna;
        
        if (esPosicionValida(nuevaFila, nuevaColumna)) {
            moverPlantaACasilla(nuevaFila, nuevaColumna);
        }
    }
    
    /**
     * Verifica si una posición del césped es válida para mover una planta
     */
    private boolean esPosicionValida(int fila, int columna) {
        return fila >= 0 && fila < FILAS_CESPED && 
               columna >= 1 && columna < COLUMNAS_CESPED;
    }
    
    /**
     * Mueve la planta seleccionada a una nueva casilla 
     */
    private void moverPlantaACasilla(int nuevaFila, int nuevaColumna) {
        if (cesped[nuevaFila][nuevaColumna] == null) {
            // Calcular nuevas coordenadas CORRECTAS
            int nuevaX = calcularPosicionXCesped(nuevaColumna);
            int nuevaY = calcularPosicionYCesped(nuevaFila);
            
            // Actualizar posición de la planta
            plantaSeleccionadaParaMover.setX(nuevaX);
            plantaSeleccionadaParaMover.setY(nuevaY);
            
            // Actualizar matriz del césped
            cesped[filaPlantaSeleccionada][columnaPlantaSeleccionada] = null;
            cesped[nuevaFila][nuevaColumna] = plantaSeleccionadaParaMover;
            
            // Actualizar posición de selección
            filaPlantaSeleccionada = nuevaFila;
            columnaPlantaSeleccionada = nuevaColumna;
        }
    }
    
    /**
     * Resetea la selección por teclado
     */
    private void resetearSeleccionTeclado() {
        plantaSeleccionadaParaMover = null;
        plantaSeleccionadaConTeclado = false;
        filaPlantaSeleccionada = -1;
        columnaPlantaSeleccionada = -1;
    }
    
    /**
     * Dibuja la planta que está siendo arrastrada
     */
    private void dibujarPlantaArrastrada() {
        if (arrastrando && plantaSeleccionada != null) {
            Color color = obtenerColorPlantaArrastrada();
            entorno.dibujarRectangulo(plantaArrastradaX, plantaArrastradaY, 50, 50, 0, color);
            
            String nombre = obtenerNombrePlantaSeleccionada();
            entorno.escribirTexto("Arrastrando: " + nombre, plantaArrastradaX, plantaArrastradaY - 40);
        }
    }
    
    /**
     * Obtiene el color para la planta arrastrada
     */
    private Color obtenerColorPlantaArrastrada() {
        switch (plantaSeleccionada) {
            case "roseblade": return new Color(255, 0, 0, 128);
            case "wallnut": return new Color(139, 69, 19, 128);
            case "iceflower": return new Color(100, 200, 255, 128);
            default: return new Color(255, 255, 255, 128);
        }
    }
    
    /**
     * Obtiene el nombre de la planta seleccionada
     */
    private String obtenerNombrePlantaSeleccionada() {
        switch (plantaSeleccionada) {
            case "roseblade": return "Rose Blade";
            case "wallnut": return "Wall Nut";
            case "iceflower": return "Ice Flower";
            default: return "Desconocida";
        }
    }
    
    /**
     * Dibuja el indicador de planta seleccionada para mover
     */
    private void dibujarPlantaSeleccionadaParaMover() {
        if (plantaSeleccionadaConTeclado && plantaSeleccionadaParaMover != null) {
            // Resaltar la planta seleccionada
            entorno.dibujarRectangulo(
                plantaSeleccionadaParaMover.getX(), 
                plantaSeleccionadaParaMover.getY(), 
                55, 55, 0, Color.YELLOW
            );
            
            // Mostrar instrucciones de movimiento
            entorno.escribirTexto("Mover con WASD - Pos: F" + filaPlantaSeleccionada + " C" + columnaPlantaSeleccionada, 
                plantaSeleccionadaParaMover.getX(), 
                plantaSeleccionadaParaMover.getY() - 40
            );
        }
    }
    
    // =====================================================================
    // SISTEMA DE VERIFICACIÓN DE CONDICIONES
    // =====================================================================
    
    /**
     * Verifica si el jugador perdió (zombies alcanzaron los regalos)
     */
    private void verificarDerrota() {
        if (zombiesAlcanzaronRegalos() || jefeAlcanzoRegalos()) {
            estadoActual = EstadoJuego.PERDIO;
            juegoPausado = true;
            tiempoDetenido = true;
        }
    }
    
    /**
     * Verifica si algún zombie alcanzó la columna de regalos
     */
    private boolean zombiesAlcanzaronRegalos() {
        for (Object zombie : zombies) {
            if (zombie != null && obtenerZombieX(zombie) < CESPED_X_INICIO + TAMANIO_CASILLA/2) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Verifica si el jefe alcanzó los regalos
     */
    private boolean jefeAlcanzoRegalos() {
        return jefe != null && jefe.getX() < CESPED_X_INICIO + TAMANIO_CASILLA/2;
    }
    
    /**
     * Verifica si se puede avanzar al siguiente nivel
     */
    private void verificarAvanceNivel() {
        if (nivelActual < TOTAL_NIVELES && 
            zombiesEliminados >= zombiesParaSiguienteNivel && 
            !nivelCompletado) {
            
            nivelCompletado = true;
            nivelActual++;
            reiniciarParaNuevoNivel();
        }
    }
    
    /**
     * Verifica si se cumplieron las condiciones de victoria
     */
    private void verificarVictoria() {
        if (nivelActual == TOTAL_NIVELES && !nivelCompletado) {
            boolean jefeDerrotado = (jefe == null || jefe.estaMuerto());
            boolean zombiesCompletados = (zombiesEliminados >= 50);
            
            if (jefeDerrotado && zombiesCompletados) {
                estadoActual = EstadoJuego.GANO;
                juegoPausado = true;
                nivelCompletado = true;
                tiempoDetenido = true;
            }
        }
    }
    
    // =====================================================================
    // SISTEMA DE PANTALLAS DE FINALIZACIÓN
    // =====================================================================
    
    /**
     * Ejecuta la pantalla de Game Over
     */
    private void ejecutarPantallaGameOver() {
        dibujarPantallaGameOver();
        procesarInputPantallaFin();
    }
    
    /**
     * Ejecuta la pantalla de Victoria
     */
    private void ejecutarPantallaVictoria() {
        dibujarPantallaVictoria();
        procesarInputPantallaFin();
    }
    
    /**
     * Dibuja la pantalla de Game Over
     */
    private void dibujarPantallaGameOver() {
        dibujarFondoPantallaFin(new Color(0, 0, 0, 200));
        
        entorno.cambiarFont("Arial", 40, Color.RED);
        entorno.escribirTexto("GAME OVER", 400, 180);
        
        dibujarEstadisticasFinJuego();
        dibujarOpcionesReinicio();
    }
    
    /**
     * Dibuja la pantalla de Victoria
     */
    private void dibujarPantallaVictoria() {
        dibujarFondoPantallaFin(new Color(0, 150, 0, 200));
        
        entorno.cambiarFont("Arial", 40, Color.GREEN);
        entorno.escribirTexto("¡VICTORIA TOTAL!", 400, 180);
        
        dibujarEstadisticasFinJuego();
        dibujarOpcionesReinicio();
    }
    
    /**
     * Dibuja el fondo para pantallas de finalización
     */
    private void dibujarFondoPantallaFin(Color color) {
        entorno.dibujarRectangulo(400, 300, 800, 600, 0, color);
    }
    
    /**
     * Dibuja las estadísticas del juego terminado
     */
    private void dibujarEstadisticasFinJuego() {
        entorno.cambiarFont("Arial", 20, Color.WHITE);
        
        if (estadoActual == EstadoJuego.PERDIO) {
            entorno.escribirTexto("Los zombies alcanzaron los regalos", 400, 230);
        } else {
            entorno.escribirTexto("Completaste todos los niveles y derrotaste al Zombie Boss", 400, 230);
        }
        
        entorno.escribirTexto("Nivel alcanzado: " + nivelActual + "/" + TOTAL_NIVELES, 400, 260);
        entorno.escribirTexto("Zombies eliminados: " + zombiesEliminados, 400, 290);
        entorno.escribirTexto("Tiempo final: " + obtenerTiempoSegundos() + " segundos", 400, 320);
    }
    
    /**
     * Dibuja las opciones de reinicio en pantallas de finalización
     */
    private void dibujarOpcionesReinicio() {
        entorno.cambiarFont("Arial", 24, Color.YELLOW);
        entorno.escribirTexto("OPCIONES:", 400, 370);
        
        entorno.cambiarFont("Arial", 20, Color.WHITE);
        entorno.escribirTexto("R - Reiniciar Juego", 400, 410);
        entorno.escribirTexto("ESC - Volver al Menú Principal", 400, 440);
    }
    
    /**
     * Procesa el input en pantallas de finalización
     */
    private void procesarInputPantallaFin() {
        if (entorno.sePresiono('r') || entorno.sePresiono('R')) {
            reiniciarJuegoCompleto();
            estadoActual = EstadoJuego.JUGANDO;
        }
        
        if (entorno.sePresiono(entorno.TECLA_ESCAPE)) {
            estadoActual = EstadoJuego.MENU_PRINCIPAL;
        }
    }
    
    // =====================================================================
    // SISTEMA DE REINICIO Y GESTIÓN DE NIVELES
    // =====================================================================
    
    /**
     * Reinicia completamente el juego para empezar desde el nivel 1
     */
    private void reiniciarJuegoCompleto() {
        reiniciarSistemaNiveles();
        reiniciarSistemaCesped();
        reiniciarSistemaEnemigos();
        reiniciarSistemaDisparos();
        reiniciarSistemaPlantas();
        reiniciarSistemaTiempo();
        reiniciarSistemaSeleccion();
    }
    
    /**
     * Reinicia el sistema de niveles
     */
    private void reiniciarSistemaNiveles() {
        this.nivelActual = 1;
        this.zombiesParaSiguienteNivel = ZOMBIES_NIVEL_1;
        this.nivelCompletado = false;
        this.jefeAparecio = false;
    }
    
    /**
     * Reinicia el césped (elimina todas las plantas)
     */
    private void reiniciarSistemaCesped() {
        for (int fila = 0; fila < FILAS_CESPED; fila++) {
            for (int columna = 0; columna < COLUMNAS_CESPED; columna++) {
                cesped[fila][columna] = null;
            }
        }
    }
    
    /**
     * Reinicia el sistema de enemigos
     */
    private void reiniciarSistemaEnemigos() {
        for (int i = 0; i < zombies.length; i++) {
            zombies[i] = null;
        }
        this.zombiesEliminados = 0;
        this.zombiesRestantes = zombiesParaSiguienteNivel;
        this.tickGeneracionZombie = 0;
        this.jefe = null;
    }
    
    /**
     * Reinicia el sistema de disparos
     */
    private void reiniciarSistemaDisparos() {
        for (int i = 0; i < bolasFuego.length; i++) {
            bolasFuego[i] = null;
        }
        for (int i = 0; i < bolasHielo.length; i++) {
            bolasHielo[i] = null;
        }
    }
    
    /**
     * Reinicia el sistema de plantas (tiempos de recarga)
     */
    private void reiniciarSistemaPlantas() {
        this.tiempoCargaRoseBlade = 0;
        this.tiempoCargaWallNut = 0;
        this.tiempoCargaIceFlower = 0;
    }
    
    /**
     * Reinicia el sistema de tiempo
     */
    private void reiniciarSistemaTiempo() {
        this.tiempoInicio = System.currentTimeMillis();
        this.tiempoTranscurrido = 0;
        this.tiempoDetenido = false;
        this.juegoPausado = false;
    }
    
    /**
     * Reinicia el sistema de selección
     */
    private void reiniciarSistemaSeleccion() {
        resetearSeleccionTeclado();
        this.plantaSeleccionada = null;
        this.arrastrando = false;
    }
    
    /**
     * Reinicia el juego para un nuevo nivel
     */
    private void reiniciarParaNuevoNivel() {
        reiniciarSistemaEnemigos();
        reiniciarSistemaDisparos();
        this.nivelCompletado = false;
        this.jefeAparecio = false;
        this.jefe = null;
    }
    
    // =====================================================================
    // MÉTODOS DE UTILIDAD
    // =====================================================================
    
    /**
     * Obtiene el tiempo transcurrido en segundos
     */
    private int obtenerTiempoSegundos() {
        if (tiempoDetenido) {
            return (int)(tiempoTranscurrido / 1000);
        } else {
            return (int)((System.currentTimeMillis() - tiempoInicio) / 1000);
        }
    }
    
    /**
     * Obtiene el nombre del nivel actual
     */
    private String obtenerNombreNivel() {
        switch (nivelActual) {
            case 1: return "INICIO";
            case 2: return "AVANZADO"; 
            case 3: return "ÉPICO";
            case 4: return "JEFE FINAL";
            default: return "DESCONOCIDO";
        }
    }
    
    /**
     * Obtiene la descripción del nivel actual
     */
    private String obtenerDescripcionNivel() {
        switch (nivelActual) {
            case 1: return "Zombies Normales";
            case 2: return "Zombies Normales y Super Zombies"; 
            case 3: return "Solo Supers Zombies";
            case 4: return "¡BOSS!";
            default: return "";
        }
    }
    
    /**
     * Verifica si el mouse está sobre un área específica
     */
    private boolean estaMouseSobreAvatar(int x, int y, int tamaño) {
        int mouseX = entorno.mouseX();
        int mouseY = entorno.mouseY();
        return mouseX >= x - tamaño/2 && mouseX <= x + tamaño/2 && 
               mouseY >= y - tamaño/2 && mouseY <= y + tamaño/2;
    }
    
    /**
     * Dibuja un zombie decorativo para el menú
     */
    private void dibujarZombieDecorativo(int x, int y) {
        entorno.dibujarCirculo(x, y, 20, new Color(0, 150, 0, 150));
        entorno.dibujarRectangulo(x, y + 15, 30, 30, 0, new Color(0, 120, 0, 150));
    }
    
    /**
     * Dibuja efectos de estrellas en el fondo del menú
     */
    private void dibujarEfectosEstrellas() {
        for (int i = 0; i < 10; i++) {
            int x = (int)(Math.random() * ANCHO_VENTANA);
            int y = (int)(Math.random() * ALTO_VENTANA);
            int tamaño = 1 + (int)(Math.random() * 3);
            entorno.dibujarCirculo(x, y, tamaño, new Color(255, 255, 255, 100));
        }
    }
    
    // =====================================================================
    // MÉTODO MAIN
    // =====================================================================
    
    /**
     * Punto de entrada principal del juego
     */
    @SuppressWarnings("unused")
    public static void main(String[] args) {
        new Juego();
    }
}