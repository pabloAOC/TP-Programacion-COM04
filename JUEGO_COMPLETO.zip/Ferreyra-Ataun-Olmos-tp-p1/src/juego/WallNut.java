package juego;

import java.awt.Color;
import java.awt.Image; 
import entorno.Entorno;
import entorno.Herramientas;

public class WallNut extends Planta {
    private Image imagenWallNut; 
    
    public WallNut(double x, double y) {
        super(x, y, "wallnut");
        this.salud = 5;
        
        // carga de imagen
        try {
            this.imagenWallNut = Herramientas.cargarImagen("img/nuez.png");
        } catch (Exception e) {
            System.out.println("Error al cargar imagen de WallNut: " + e.getMessage());
            this.imagenWallNut = null;
        }
    }
    
    @Override
    public void dibujar(Entorno entorno) {
        //  código de dibujo geométrico con esto:
        if (imagenWallNut != null) {
            // Dibujar la imagen
            entorno.dibujarImagen(imagenWallNut, x, y, 0, 0.7); // Ajusta 0.4 al tamaño que quieras
        } else {
            // Código original como respaldo si no hay imagen
            Color colorCascara = salud < 3 ? new Color(160, 80, 30) : new Color(139, 69, 19);
            Color colorInterior = salud < 3 ? new Color(230, 200, 160) : new Color(210, 180, 140);
            
            entorno.dibujarRectangulo(x, y, 50, 50, 0, colorCascara);
            entorno.dibujarRectangulo(x, y, 30, 30, 0, colorInterior);
        }
        
        // estos elementos de información (opcional)
        entorno.escribirTexto("WN " + salud, x - 12, y + 5);
        
        // Barra de salud (opcional - puedes quitarla si prefieres)
        double anchoBarraSalud = 40 * ((double)salud / 5);
        Color colorBarra = salud > 3 ? Color.GREEN : salud > 1 ? Color.YELLOW : Color.RED;
        entorno.dibujarRectangulo(x, y - 35, anchoBarraSalud, 4, 0, colorBarra);
    }
}