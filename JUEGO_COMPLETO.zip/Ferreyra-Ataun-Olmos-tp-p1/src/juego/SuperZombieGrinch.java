package juego;

import java.awt.Color;
import java.awt.Image; 
import entorno.Entorno;
import entorno.Herramientas;

public class SuperZombieGrinch extends ZombieGrinch {
    private boolean inmuneACongelacion;
    private Image imagenSuperZombie;
    
    public SuperZombieGrinch(double x, double y, int fila) {
        super(x, y, fila);
        setSalud(10);        
        setVelocidad(0.6);
        this.inmuneACongelacion = true;
        
        // carga de imagen
        try {
            this.imagenSuperZombie = Herramientas.cargarImagen("img/super_zombie_grinch.png");
        } catch (Exception e) {
            System.out.println("Error al cargar imagen del super zombie: " + e.getMessage());
            this.imagenSuperZombie = null;
        }
    }
    
    /**
     * Getter para verificar inmunidad
     */
    public boolean esInmuneACongelacion() {
        return inmuneACongelacion;
    }
    
    /**
     * Aplica ralentización pero NO congelación completa
     */
    public void aplicarRalentizacion(double factor) {
        // El super zombie se ralentiza pero no se congela completamente
        double nuevaVelocidad = 0.3 * Math.max(0.5, factor); // Mínimo 50% de velocidad
        setVelocidad(nuevaVelocidad);
    }
    
    @Override
    public void dibujar(Entorno entorno) {
        // ← REEMPLAZAR código de dibujo geométrico con imagen
        if (imagenSuperZombie != null) {
            // Dibujar la imagen del super zombie
            entorno.dibujarImagen(imagenSuperZombie, getX(), getY(), 0, 0.8); // Tamaño un poco mayor
        } else {
            // Código original como respaldo si no hay imagen
            dibujarGeometrico(entorno);
        }
        
        // elementos UI importantes
        
        // Barra de salud naranja (proporcional a 8 puntos de vida)
        double anchoBarraSalud = 40 * ((double)getSalud() / 8);
        entorno.dibujarRectangulo(getX(), getY() - 45, anchoBarraSalud, 6, 0, Color.ORANGE);
        
        // Indicador de inmunidad al hielo
        if (inmuneACongelacion) {
            entorno.dibujarRectangulo(getX(), getY() - 55, 20, 3, 0, Color.CYAN);
            entorno.escribirTexto("INMUNE HIELO", getX() - 25, getY() - 60);
        }
        
        // Texto identificador
        entorno.escribirTexto("SUPER", getX() - 15, getY() + 50);
    }
    
    /**
     * Método de respaldo para dibujo geométrico
     */
    private void dibujarGeometrico(Entorno entorno) {
        Color colorCuerpo = estaAtacando() ? new Color(0, 0, 150) : Color.BLUE;
        entorno.dibujarRectangulo(getX(), getY(), 45, 65, 0, colorCuerpo);
        
        entorno.dibujarCirculo(getX(), getY() - 15, 28, colorCuerpo);
        entorno.dibujarCirculo(getX() - 8, getY() - 18, 6, Color.WHITE);
        entorno.dibujarCirculo(getX() + 8, getY() - 18, 6, Color.WHITE);
        
        // Corona amarilla
        entorno.dibujarRectangulo(getX(), getY() - 40, 25, 8, 0, Color.YELLOW);
        entorno.dibujarRectangulo(getX() - 8, getY() - 35, 5, 10, 0.5, Color.YELLOW);
        entorno.dibujarRectangulo(getX() + 8, getY() - 35, 5, 10, -0.5, Color.YELLOW);
    }
}