package juego;

import java.awt.Color;
import java.awt.Image; 
import entorno.Entorno;
import entorno.Herramientas; 

public class RoseBlade extends Planta {
    private int tiempoRecarga;
    private static final int RECARGA_MAXIMA = 120;
    private Image imagenRoseBlade; // variable para la imagen
    
    public RoseBlade(double x, double y) {
        super(x, y, "roseblade");
        this.salud = 1;
        this.tiempoRecarga = RECARGA_MAXIMA;
        
        // carga de imagen
        try {
            this.imagenRoseBlade = Herramientas.cargarImagen("img/rose_blade.png");
        } catch (Exception e) {
            System.out.println("Error al cargar imagen de RoseBlade: " + e.getMessage());
            this.imagenRoseBlade = null;
        }
    }
    
    @Override
    public void dibujar(Entorno entorno) {
        // código de dibujo geométrico con esto:
        if (imagenRoseBlade != null) {
            // Dibujar la imagen
            entorno.dibujarImagen(imagenRoseBlade, x, y, 0, 0.7); // Ajusta 0.4 al tamaño que quieras
        } else {
            // Código original como respaldo si no hay imagen
            Color colorFlor = salud > 0 ? Color.RED : new Color(100, 0, 0);
            entorno.dibujarRectangulo(x, y, 40, 40, 0, colorFlor);
            entorno.dibujarRectangulo(x, y + 25, 5, 20, 0, Color.GREEN);
        }
        
        // elementos de información (opcional)
        entorno.escribirTexto("RB " + salud, x - 12, y + 5);
        
        if (tiempoRecarga > 0 && salud > 0) {
            double progreso = 1.0 - (double)tiempoRecarga / RECARGA_MAXIMA;
            entorno.dibujarRectangulo(x, y - 30, 30 * progreso, 3, 0, Color.YELLOW);
        }
        
        if (salud == 0) {
            entorno.escribirTexto("MUERTA", x - 15, y - 40);
        }
    }
    
    // todos los demás métodos igual
    
    public void actualizar() {
        if (tiempoRecarga > 0 && salud > 0) {
            tiempoRecarga--;
        }
    }
    
    public boolean puedeDisparar() {
        return tiempoRecarga == 0 && salud > 0;
    }
    
    @Override
    public boolean estaViva() {
        return salud > 0;
    }
    
    public void reiniciarRecarga() {
        tiempoRecarga = RECARGA_MAXIMA;
    }
    
    public boolean hayZombiesEnFilaYDelante(Object[] zombies, int fila, double posicionXPlanta) {
        for (Object obj : zombies) {
            if (obj instanceof ZombieGrinch) {
                ZombieGrinch zombie = (ZombieGrinch) obj;
                if (zombie != null && zombie.getFila() == fila && !zombie.estaMuerto()) {
                    if (zombie.getX() > posicionXPlanta) {
                        return true;
                    }
                }
            } else if (obj instanceof SuperZombieGrinch) {
                SuperZombieGrinch zombie = (SuperZombieGrinch) obj;
                if (zombie != null && zombie.getFila() == fila && !zombie.estaMuerto()) {
                    if (zombie.getX() > posicionXPlanta) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}