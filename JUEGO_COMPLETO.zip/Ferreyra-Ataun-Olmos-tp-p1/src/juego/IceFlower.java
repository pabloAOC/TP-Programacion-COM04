package juego;

import java.awt.Color;
import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;

/**
 * Planta IceFlower - Dispara bolas de hielo
 * - Ralentiza zombies progresivamente
 * - Congela zombies después de 3 hits
 * - Disponible desde el nivel 2
 */
public class IceFlower extends Planta {
    private int tiempoRecarga;
    private static final int RECARGA_MAXIMA = 200;
    private Image imagenIceFlower;
    
    public IceFlower(double x, double y) {
        super(x, y, "iceflower");
        this.salud = 2;
        this.tiempoRecarga = RECARGA_MAXIMA;
        
        // carga de imagen
        try {
            this.imagenIceFlower = Herramientas.cargarImagen("img/ice_flower.png");
        } catch (Exception e) {
            System.out.println("Error al cargar imagen de IceFlower: " + e.getMessage());
            this.imagenIceFlower = null;
        }
    }
    
    @Override
    public void dibujar(Entorno entorno) {
        // el código de dibujo geométrico con esto:
        if (imagenIceFlower != null) {
            // Dibujar la imagen
            entorno.dibujarImagen(imagenIceFlower, x, y, 0, 0.7); // Ajusta 0.4 al tamaño que quieras
        } else {
            // Código original como respaldo si no hay imagen
            Color colorFlor = new Color(100, 200, 255);
            entorno.dibujarRectangulo(x, y, 40, 40, 0, colorFlor);
            entorno.dibujarRectangulo(x, y + 25, 5, 20, 0, Color.CYAN);
        }
        
        // estos elementos de información (opcional)
        entorno.escribirTexto("IF " + salud, x - 10, y + 5);
        
        // Barra de recarga visual
        if (tiempoRecarga > 0 && salud > 0) {
            double progreso = 1.0 - (double)tiempoRecarga / RECARGA_MAXIMA;
            entorno.dibujarRectangulo(x, y - 30, 30 * progreso, 3, 0, Color.CYAN);
        }
    }
    
    /**
     * Actualiza el temporizador de recarga
     */
    public void actualizar() {
        if (tiempoRecarga > 0 && salud > 0) {
            tiempoRecarga--;
        }
    }
    
    /**
     * Verifica si puede disparar (recarga completa y viva)
     */
    public boolean puedeDisparar() {
        return tiempoRecarga == 0 && salud > 0;
    }
    
    /**
     * Verifica si la planta está viva
     */
    public boolean estaViva() {
        return salud > 0;
    }
    
    /**
     * Reinicia el temporizador de recarga
     */
    public void reiniciarRecarga() {
        tiempoRecarga = RECARGA_MAXIMA;
    }
    
    /**
     * Verifica si hay zombies en la misma fila y adelante de la planta
     */
    public boolean hayZombiesEnFilaYDelante(Object[] zombies, int fila, double posicionXPlanta) {
        for (Object obj : zombies) {
            if (obj instanceof ZombieGrinch) {
                ZombieGrinch zombie = (ZombieGrinch) obj;
                if (zombie != null && zombie.getFila() == fila && !zombie.estaMuerto()) {
                    if (zombie.getX() > posicionXPlanta) {
                        return true;
                    }
                }
            } else if (obj instanceof SuperZombieGrinch) {
                SuperZombieGrinch zombie = (SuperZombieGrinch) obj;
                if (zombie != null && zombie.getFila() == fila && !zombie.estaMuerto()) {
                    if (zombie.getX() > posicionXPlanta) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}