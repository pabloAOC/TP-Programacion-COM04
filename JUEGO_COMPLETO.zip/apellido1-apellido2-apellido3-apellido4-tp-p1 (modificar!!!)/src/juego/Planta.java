package juego;

import java.awt.Color;
import entorno.Entorno;

public abstract class Planta {
    protected double x;
    protected double y;
    protected int salud;
    protected String tipo;
    
    public Planta(double x, double y, String tipo) {
        this.x = x;
        this.y = y;
        this.tipo = tipo;
    }
    
    public double getX() { return x; }
    public double getY() { return y; }
    public int getSalud() { return salud; }
    public String getTipo() { return tipo; }
    public void setSalud(int salud) { this.salud = salud; }
    public void setX(double x) { this.x = x; }
    public void setY(double y) { this.y = y; }
    
    public boolean estaViva() {
        return salud > 0;
    }
    
    public abstract void dibujar(Entorno entorno);
}