package juego;

import java.awt.Color;
import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;

/**
 * Clase que representa al zombie básico del juego.
 * - Se mueve hacia la izquierda atacando plantas
 * - Tiene salud y velocidad base
 * - Puede ser ralentizado por bolas de hielo
 * - Ataca plantas cuando están cerca
 */
public class ZombieGrinch {
    private double x;        // Posición en el eje X
    private double y;        // Posición en el eje Y
    private double velocidad; // Velocidad de movimiento (puede ser modificada por hielo)
    private int salud;       // Salud del zombie (4 puntos base)
    private int fila;        // Fila en la que se encuentra (0-4)
    private boolean atacando; // Indica si está atacando una planta
    private Planta plantaObjetivo; // Planta que está siendo atacada
    private int tickAtaque;  // Contador para temporizar los ataques
    private Image imagenZombie; // variable para la imagen
    private Image imagenZombieAtacando; // imagen para estado de ataque (opcional)
    
    /**
     * Constructor del zombie básico
     * @param x Posición inicial en X
     * @param y Posición inicial en Y
     * @param fila Fila asignada (0-4)
     */
    public ZombieGrinch(double x, double y, int fila) {
        this.x = x;
        this.y = y;
        this.fila = fila;
        this.velocidad = 0.5;  // Velocidad base
        this.salud = 4;        // Salud base
        this.atacando = false;
        this.plantaObjetivo = null;
        this.tickAtaque = 0;
        
        // carga de imágenes
        try {
            this.imagenZombie = Herramientas.cargarImagen("img/zombie_grinch.png");
            this.imagenZombieAtacando = Herramientas.cargarImagen("img/zombie_grinch.png");
        } catch (Exception e) {
            System.out.println("Error al cargar imágenes del zombie: " + e.getMessage());
            this.imagenZombie = null;
            this.imagenZombieAtacando = null;
        }
    }
    
    // ==================== GETTERS Y SETTERS ====================
    // todos los getters y setters existentes SIN CAMBIOS
    public double getX() { 
    	return x; 
    }
    
    public double getY() { 
    	return y; 
    }
    
    public int getSalud() { 
    	return salud; 
    }
    
    public int getFila() { 
    	return fila; 
    }
    
    public boolean estaAtacando() { 
    	return atacando; 
    }
    
    public void setSalud(int salud) { 
    	this.salud = salud; 
    }
    
    public void setVelocidad(double velocidad) { 
    	this.velocidad = velocidad; 
    }
    
    public double getVelocidad() { 
    	return velocidad; 
    }
    
    // ==================== MÉTODOS DE COMPORTAMIENTO ====================
    // todos los métodos de comportamiento SIN CAMBIOS
    public void mover(Planta[][] cesped) {
        if (atacando) {
            return;
        }
        
        Planta plantaCercana = detectarPlantaCercana(cesped);
        if (plantaCercana != null) {
            atacando = true;
            plantaObjetivo = plantaCercana;
        } else {
            this.x -= velocidad;
        }
    }
    
    public void atacar() {
        if (atacando && plantaObjetivo != null) {
            tickAtaque++;
            
            if (tickAtaque >= 60) {
                plantaObjetivo.setSalud(plantaObjetivo.getSalud() - 1);
                tickAtaque = 0;
                
                if (plantaObjetivo.getSalud() <= 0) {
                    atacando = false;
                    plantaObjetivo = null;
                }
            }
        }
    }
    
    private Planta detectarPlantaCercana(Planta[][] cesped) {
        for (int col = 0; col < cesped[0].length; col++) {
            if (cesped[fila][col] != null) {
                Planta planta = cesped[fila][col];
                double distancia = Math.abs(this.x - planta.getX());
                
                if (distancia < 50) {
                    return planta;
                }
            }
        }
        return null;
    }
    
    public void recibirDano() {
        this.salud--;
    }
    
    public boolean estaMuerto() {
        return salud <= 0;
    }
    
    // ==================== MÉTODOS GRÁFICOS ====================
    
    /**
     * Dibuja el zombie en el entorno gráfico
     * @param entorno Entorno donde se dibujará
     */
    public void dibujar(Entorno entorno) {
        // código de dibujo geométrico con esto:
        if (imagenZombie != null) {
            // Seleccionar imagen según estado
            Image imagenActual = atacando && imagenZombieAtacando != null ? 
                               imagenZombieAtacando : imagenZombie;
            
            // Dibujar la imagen del zombie
            entorno.dibujarImagen(imagenActual, x, y, 0, 0.8); // Ajusta 0.5 al tamaño que quieras
        } else {
            // Código original como respaldo si no hay imágenes
            dibujarGeometrico(entorno);
        }
        
        // elementos de información y UI
        // Barra de salud (proporcional a los 4 puntos base)
        double anchoBarraSalud = 40 * ((double)salud / 4);
        entorno.dibujarRectangulo(x, y - 35, anchoBarraSalud, 5, 0, Color.RED);
        
        // Indicador visual de ataque
        if (atacando) {
            entorno.dibujarRectangulo(x, y - 45, 30, 3, 0, Color.ORANGE);
            entorno.escribirTexto("ATACANDO", x - 25, y - 50);
        }
        
        // Información de debug: fila y salud
        entorno.escribirTexto("F" + fila + " S:" + salud, x, y + 45);
    }
    
    /**
     * Método de respaldo para dibujo geométrico si no se cargan las imágenes
     */
    private void dibujarGeometrico(Entorno entorno) {
        // Color del cuerpo (verde normal o verde oscuro si está atacando)
        Color colorCuerpo = atacando ? new Color(0, 150, 0) : Color.GREEN;
        
        // Cuerpo principal del zombie
        entorno.dibujarRectangulo(x, y, 40, 60, 0, colorCuerpo);
        
        // Cabeza del zombie
        entorno.dibujarCirculo(x, y - 15, 25, colorCuerpo);
        
        // Ojos del zombie
        entorno.dibujarCirculo(x - 8, y - 18, 5, Color.BLACK);
        entorno.dibujarCirculo(x + 8, y - 18, 5, Color.BLACK);
        
        // Boca del zombie (roja si está atacando)
        Color colorBoca = atacando ? Color.RED : new Color(200, 0, 0);
        entorno.dibujarRectangulo(x, y - 5, 15, 3, 0, colorBoca);
    }
}