package juego;

import java.awt.Color;
import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;

/**
 * Zombie Boss final del juego
 * - Tiene mucha vida (100 puntos)
 * - Ataque lento que mata plantas aleatoriamente en todo el tablero
 * - Es inmune a congelación completa, solo se ralentiza
 * - Aparece en el nivel 4
 */
public class ZombieBoss {
    private double x, y;
    private double velocidad;
    private double velocidadBase;
    private int salud;
    private int tickAtaque;
    private final int RECARGA_ATAQUE = 600;
    private boolean ataqueActivo;
    private int tickRalentizacion;
    private Image imagenBoss;
    
    public ZombieBoss(double x, double y) {
        this.x = x;
        this.y = y;
        this.velocidadBase = 0.08;
        this.velocidad = velocidadBase;
        this.salud = 100;
        this.tickAtaque = 0;
        this.ataqueActivo = false;
        this.tickRalentizacion = 0;
        
        // ← AÑADIR carga de imagen
        try {
            this.imagenBoss = Herramientas.cargarImagen("img/zombie_boss.png");
        } catch (Exception e) {
            System.out.println("Error al cargar imagen del Zombie Boss: " + e.getMessage());
            this.imagenBoss = null;
        }
    }
    
    // Getters para acceso externo
    public double getX() { return x; }
    public double getY() { return y; }
    public int getSalud() { return salud; }
    public boolean isAtaqueActivo() { return ataqueActivo; }
    
    /**
     * Mueve al jefe hacia la izquierda
     */
    public void mover() {
        this.x -= velocidad;
        
        // Actualizar efecto de ralentización temporal
        if (tickRalentizacion > 0) {
            tickRalentizacion--;
            if (tickRalentizacion == 0) {
                // Restaurar velocidad normal cuando termina el efecto
                velocidad = velocidadBase;
            }
        }
    }
    
    /**
     * Actualiza el temporizador de ataque
     */
    public void actualizar() {
        tickAtaque++;
        if (tickAtaque >= RECARGA_ATAQUE) {
            ataqueActivo = true;
            tickAtaque = 0;
        }
    }
    
    /**
     * Ejecuta el ataque masivo que mata 5 plantas aleatoriamente
     * @param cesped Matriz de plantas del juego
     */
    public void ejecutarAtaque(Planta[][] cesped) {
        if (ataqueActivo) {
            int plantasMatadas = 0;
            int intentos = 0;
            int maxIntentos = 20;
            
            // Matar exactamente 5 plantas aleatoriamente
            while (plantasMatadas < 5 && intentos < maxIntentos) {
                int filaAleatoria = (int)(Math.random() * cesped.length);
                int columnaAleatoria = (int)(Math.random() * cesped[0].length);
                
                if (cesped[filaAleatoria][columnaAleatoria] != null && 
                    cesped[filaAleatoria][columnaAleatoria].estaViva()) {
                    
                    cesped[filaAleatoria][columnaAleatoria].setSalud(0);
                    plantasMatadas++;
                }
                intentos++;
            }
            
            ataqueActivo = false;
        }
    }
    
    /**
     * Aplica efecto de ralentización al jefe (solo ralentización, NO congelación)
     * @param factor Factor de ralentización (0.0 a 1.0)
     */
    public void aplicarRalentizacion(double factor) {
        // El jefe solo se ralentiza, no se congela completamente
        double nuevaVelocidad = velocidadBase * Math.max(0.3, factor); // Mínimo 30% de velocidad
        if (nuevaVelocidad < velocidad) {
            velocidad = nuevaVelocidad;
            tickRalentizacion = 180; // Efecto dura 3 segundos
        }
    }
    
    /**
     * Reduce la salud del jefe
     */
    public void recibirDano(int dano) {
        this.salud -= dano;
    }
    
    /**
     * Verifica si el jefe está muerto
     */
    public boolean estaMuerto() {
        return salud <= 0;
    }
    
    /**
     * Dibuja al jefe con imagen y barras de información
     */
    public void dibujar(Entorno entorno) {
        // código de dibujo geométrico con imagen
        if (imagenBoss != null) {
            // Dibujar la imagen del jefe
            entorno.dibujarImagen(imagenBoss, x, y, 0, 0.8); // Escala mayor por ser el jefe
        } else {
            // Código original como respaldo si no hay imagen
            dibujarGeometrico(entorno);
        }
        
        // elementos UI importantes
        
        // Barra de salud (proporcional a los 100 puntos de vida)
        double anchoBarraSalud = 70 * ((double)salud / 100);
        Color colorBarraSalud = salud > 50 ? Color.RED : salud > 25 ? Color.ORANGE : Color.YELLOW;
        entorno.dibujarRectangulo(x, y - 150, anchoBarraSalud, 10, 0, colorBarraSalud);
        
        // Barra de carga de ataque
        double progresoAtaque = (double)tickAtaque / RECARGA_ATAQUE;
        entorno.dibujarRectangulo(x, y - 165, 70 * progresoAtaque, 5, 0, Color.MAGENTA);
        
        // Indicador de ralentización
        if (tickRalentizacion > 0) {
            entorno.dibujarRectangulo(x, y - 175, 30, 3, 0, Color.CYAN);
            entorno.escribirTexto("RALENTIZADO", x - 25, y - 185);
        }
        
        // Texto informativo
        entorno.escribirTexto("BOSS " + salud + "/100", x - 25, y - 160);
        
        // Advertencia de ataque inminente
        if (ataqueActivo) {
            entorno.escribirTexto("¡ATAQUE INMINENTE!", x - 40, y - 200);
        }
    }
    
    /**
     * Método de respaldo para dibujo geométrico
     */
    private void dibujarGeometrico(Entorno entorno) {
        Color colorCuerpo = new Color(128, 0, 128);
        
        // Cuerpo del jefe
        entorno.dibujarRectangulo(x, y, 80, 200, 0, colorCuerpo);
        entorno.dibujarCirculo(x, y - 90, 40, colorCuerpo);
        
        // Ojos
        entorno.dibujarCirculo(x - 15, y - 95, 8, Color.RED);
        entorno.dibujarCirculo(x + 15, y - 95, 8, Color.RED);
        
        // Corona
        entorno.dibujarRectangulo(x, y - 130, 50, 12, 0, Color.YELLOW);
        entorno.dibujarRectangulo(x - 15, y - 120, 8, 15, 0.5, Color.YELLOW);
        entorno.dibujarRectangulo(x + 15, y - 120, 8, 15, -0.5, Color.YELLOW);
        entorno.dibujarRectangulo(x, y - 120, 8, 15, 0, Color.YELLOW);
    }
}