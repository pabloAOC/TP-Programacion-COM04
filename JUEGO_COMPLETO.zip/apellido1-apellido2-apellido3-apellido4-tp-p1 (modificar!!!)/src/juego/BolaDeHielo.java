package juego;

import java.awt.Color;
import entorno.Entorno;

/**
 * Representa una bola de hielo disparada por IceFlower
 * - Ralentiza zombies progresivamente
 * - Congela completamente después de 3 hits
 * - Se mueve más lento que las bolas de fuego
 */
public class BolaDeHielo {
    private double x;
    private double y;
    private double velocidad;
    private int dano;
    private int hits;
    private boolean activa; // Controla si la bola sigue activa después de golpear
    
    public BolaDeHielo(double x, double y) {
        this.x = x;
        this.y = y;
        this.velocidad = 1.5; // Más lenta que la bola de fuego
        this.dano = 1;
        this.hits = 0;
        this.activa = true; // La bola comienza activa
    }
    
    // Getters para acceso externo
    public double getX() { return x; }
    public double getY() { return y; }
    public int getDano() { return dano; }
    public int getHits() { return hits; }
    public boolean isActiva() { return activa; }
    
    public void incrementarHits() { 
        this.hits++; 
        // Si llega a 3 hits, la bola se desactiva (se usa para congelar)
        if (this.hits >= 3) {
            this.activa = false;
        }
    }
    
    public void desactivar() {
        this.activa = false;
    }
    
    /**
     * Mueve la bola de hielo hacia la derecha
     */
    public void mover() {
        if (activa) {
            this.x += velocidad;
        }
    }
    
    /**
     * Verifica si la bola salió de la pantalla
     */
    public boolean estaFueraDePantalla(int anchoPantalla) {
        return x > anchoPantalla + 50 || !activa;
    }
    
    /**
     * Dibuja la bola de hielo con efectos visuales
     */
    public void dibujar(Entorno entorno) {
        if (!activa) return;
        
        // Bola de hielo principal
        entorno.dibujarCirculo(x, y, 12, Color.BLUE);
        entorno.dibujarCirculo(x, y, 8, Color.BLUE);
        
        // Efecto de cristales de hielo
        entorno.dibujarRectangulo(x + 6, y, 3, 8, 0.2, new Color(200, 230, 255));
        entorno.dibujarRectangulo(x - 6, y, 3, 8, -0.2, new Color(200, 230, 255));
        
        // Indicador de hits acumulados
        if (hits > 0) {
            entorno.escribirTexto("" + hits, x, y - 15);
        }
    }
}