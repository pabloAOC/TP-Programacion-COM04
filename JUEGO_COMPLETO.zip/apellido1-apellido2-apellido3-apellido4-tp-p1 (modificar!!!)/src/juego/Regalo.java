package juego;

import java.awt.Color;
import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;

public class Regalo {
    private double x;
    private double y;
    private boolean destruido;
    private Image imagenRegalo;
    
    public Regalo(double x, double y) {
        this.x = x;
        this.y = y;
        this.destruido = false;
        
        // Cargar la imagen del regalo
        try {
            this.imagenRegalo = Herramientas.cargarImagen("img/regalo.png");
        } catch (Exception e) {
            System.out.println("Error al cargar imagen del regalo: " + e.getMessage());
            this.imagenRegalo = null;
        }
    }
    
    public double getX() { return x; }
    public double getY() { return y; }
    public boolean isDestruido() { return destruido; }
    public void destruir() { this.destruido = true; }
    
    public void dibujar(Entorno entorno) {
        if (destruido) return;
        
        if (imagenRegalo != null) {
            // SOLO LA IMAGEN - sin animaciones
            entorno.dibujarImagen(imagenRegalo, x, y, 0, 0.8); // Ajusta el 0.4 al tamaño que prefieras
        } else {
            // Código de respaldo si no se carga la imagen
            dibujarGeometrico(entorno);
        }
    }
    
    // Método de respaldo por si falla la carga de la imagen
    private void dibujarGeometrico(Entorno entorno) {
        // Caja del regalo
        entorno.dibujarRectangulo(x, y, 50, 50, 0, Color.RED);
        
        // Moño
        entorno.dibujarRectangulo(x, y - 10, 40, 8, 0, Color.GREEN);
        entorno.dibujarRectangulo(x, y, 8, 40, 0, Color.GREEN);
        
        // Detalles decorativos
        entorno.dibujarRectangulo(x, y, 50, 5, 0, Color.WHITE);
        entorno.dibujarRectangulo(x, y, 5, 50, 0, Color.WHITE);
    }
}